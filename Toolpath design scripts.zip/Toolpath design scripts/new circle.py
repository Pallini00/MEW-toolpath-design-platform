from intersecting_structure_generation import remove_adjacent_duplicates, Path_fill
from math import pi, cos, sin
import numpy as np
import matplotlib.pyplot as plt


# 生成圆的坐标点
def generate_circle_points(radius=1):
    # 生成足够多的点以确保圆的完整性
    angles = np.linspace(0, 2 * pi, 300)  # 生成1000个点
    x = radius * np.cos(angles)  # 计算x坐标
    y = radius * np.sin(angles)  # 计算y坐标
    return np.column_stack((x, y))  # 返回点的坐标数组

# 生成圆的点
pts = generate_circle_points(radius=1)

# 使用 Path_fill 控制点与点之间的距离
pts = Path_fill(points=pts, max_dis=0.1)  # max_dis 控制点与点之间的最大距离
pts = remove_adjacent_duplicates(pts)

# 绘制图形
plt.plot(pts[:, 0], pts[:, 1], marker='o', markersize=2, linestyle='-')
plt.axis('equal')
plt.show()
# 输出结果
for point in pts:
    print(f"{point[0]:.2f} {point[1]:.2f} v")