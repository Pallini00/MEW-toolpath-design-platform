import numpy as np
import matplotlib.pyplot as plt
from math import sqrt, pi
from circle_ary import arc  # 圆弧生成函数

# 基础参数配置
circle_number = 11  # 圆弧数量（建议保持奇数）
radius = 1         # 圆弧半径
side_offset = 10   # 边界偏移
row_dis = sqrt(3) * radius  # 行间距
alternate = sqrt(3)/2 * radius  # 交错偏移量
max_dis = 0.1      # 圆弧细分精度

# 初始化点集
pts_x = np.array([])
pts_y = np.array([])

# 基础圆弧生成循环（仅保留核心部分）
for i in range(int(circle_number / 2)):
    # 上行圆弧生成
    for j in range(circle_number):
        center_x = side_offset + (0.5 + j) * radius
        center_y = 2 * i * row_dis + (-1)**(j+1) * alternate
        start_angle = 2/3 * pi * (-1)**j
        stop_angle = 1/3 * pi * (-1)**j
        
        arc_x, arc_y = arc(center_x, center_y, radius, 
                          start_angle, stop_angle, max_dis)
        pts_x = np.hstack((pts_x, arc_x))
        pts_y = np.hstack((pts_y, arc_y))
    
    # 下行圆弧生成
    for j in range(circle_number):
        center_x = side_offset + circle_number*radius - (0.5+j)*radius
        center_y = (2*i + 1)*row_dis + (-1)**(j+1)*alternate
        start_angle = 2/3 * pi * (-1)**j
        stop_angle = pi * (-1)**j
        
        arc_x, arc_y = arc(center_x, center_y, radius,
                          start_angle, stop_angle, max_dis)
        pts_x = np.hstack((pts_x, arc_x))
        pts_y = np.hstack((pts_y, arc_y))

# 直接绘制基础圆弧
plt.figure(figsize=(10, 10))
plt.plot(pts_x, pts_y, 'black', linewidth=1)
# plt.scatter(pts_x, pts_y, s=1, color='r', alpha=0.3)  # 显示路径点
plt.axis('equal')
plt.title("Basic Arc Pattern Without Rotation")
plt.grid(False)
plt.show()