import matplotlib.pyplot as plt
import numpy as np

# 创建角度的数组
theta = np.linspace(0, 2*np.pi, 100)

# 半径为1的圆的x和y坐标
x = np.cos(theta)
y = np.sin(theta)

# 输出每个点的坐标
for i in range(len(x)):
    print(f"{x[i]:.2f} {y[i]:.2f} v")

# 绘制圆
plt.figure(figsize=(6,6))
plt.plot(x, y)

# 设置坐标轴比例相等
plt.gca().set_aspect('equal', adjustable='box')

# 设置图形标题
plt.title('Circle with radius 1')

# 显示图形
plt.grid(True)
plt.show()
