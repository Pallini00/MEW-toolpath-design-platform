import numpy as np
from matplotlib import pyplot as plt
from math import sin, cos, tan, sqrt, pi
a = 10
row_number = 24
#row_number一定是一个偶数的2倍！
col_number = 48
#col_number一定是一个偶数的2倍！
pts_single_x = np.array(0)
pts_single_y = np.array(0)
#定位旋转中心
center_x = col_number * 0.25 * (a+ a * 0.5 * sqrt(2)) - 0.5 * a
center_y = (row_number * 0.5 - 1) * (a + a * 0.5 * sqrt(2)) + 0.5 * a + 0.25 * a * sqrt(2)
#成形单元只包括一个点，只需要研究点的位置变化，y一直在跳跃，回程的时候改变一下x的变化方向
for i in range(row_number):
    for j in range(col_number):
        if i % 2 == 0:
            if j % 2 == 0:
                pt_x = (a + a * 0.5 * sqrt(2)) * j * 0.5
            else:
                pt_x = a * 0.5 * sqrt(2) + (a + a * 0.5 * sqrt(2)) * (j - 1) * 0.5
        else:
            if j % 2 == 0:
                pt_x = (a + a * 0.5 * sqrt(2)) * (col_number - j) * 0.5
            else:
                pt_x = a * 0.5 * sqrt(2) + (a + a * 0.5 * sqrt(2)) * (col_number - 1 - j) * 0.5
        pt_y = (-1) ** (i + j + 1) * (-1) ** (int((i + j) * 0.5)) * a * 0.25 *sqrt(2)* (-1) ** (int(i / 2)) + (a + a * 0.5 * sqrt(2)) * i
        pts_single_x = np.append(pts_single_x, pt_x)
        pts_single_y = np.append(pts_single_y, pt_y)
#原点移动至图形中心（一定在某八边形形中心），以便旋转。
pts_single_x = pts_single_x-center_x
pts_single_y = pts_single_y-center_y
#插入过渡点，避免过渡线影响内部结构
pt_insert_1_x = pts_single_x[-1]-col_number*sqrt(3)/40*a
pt_insert_1_y = pts_single_y[-1]
pt_insert_2_x = pt_insert_1_x
# 旋转90度
pts_single_x_rotated_1, pts_single_y_rotated_1 = pts_single_x*cos(pi/2)-pts_single_y*sin(pi/2),\
    pts_single_x*sin(pi/2)+pts_single_y*cos(pi/2)
pt_insert_2_y = pts_single_y_rotated_1[1]
#所有取向与过渡点拼接
pts_single_x = np.hstack((pts_single_x, np.array(pt_insert_1_x),np.array(pt_insert_2_x), pts_single_x_rotated_1))
pts_single_y = np.hstack((pts_single_y, np.array(pt_insert_1_y), np.array(pt_insert_2_y), pts_single_y_rotated_1))
plt.plot(pts_single_x, pts_single_y)
plt.axis('equal')
plt.show()