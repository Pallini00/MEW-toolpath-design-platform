import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
from matplotlib.colors import LinearSegmentedColormap

# ===== 用户可调参数 =====
params = {
    'd': 5,               # y递减步长 (可修改)
    'width': 32,          # 矩形宽度
    'length': 69.08, # 矩形长度 ≈69.08
    'max_cycles': 1      # 最大循环次数（安全阈值）
}

# ===== 初始化设置 =====
width, length, d = params['width'], params['length'], params['d']
colors = plt.cm.rainbow(np.linspace(0, 1, params['max_cycles']))  # 彩虹色循环

# 创建图形
fig, ax = plt.subplots(figsize=(12, 8))
plt.title(f'Periodic Toolpath (d={d}mm)', fontsize=14, fontweight='bold')
plt.grid(True, linestyle='--', alpha=0.5)

# 绘制矩形
rectangle = patches.Rectangle((0, 0), width, length, linewidth=2, 
                             edgecolor='#1f77b4', facecolor='#aec7e8', alpha=0.3, zorder=1)
ax.add_patch(rectangle)
ax.set_xlim(-5, width + 5)
ax.set_ylim(-5, length + 5)
ax.set_aspect('equal')

# ===== 生成原始折线（红色） =====
def generate_initial_path():
    points = [(0, length)]  # 从D点开始
    current_distance = d
    while current_distance < length:
        y_bc = length - current_distance
        points.append((width, y_bc))
        current_distance += d
        if current_distance >= length:
            break
        y_ad = length - current_distance
        points.append((0, y_ad))
        current_distance += d
    return points

original_path = generate_initial_path()
plt.plot(*zip(*original_path), 'r-o', lw=2, markersize=6, zorder=2, label='Original path')

# ===== 周期性延伸折线 =====
def segments_congruent(seg1, seg2):
    """检查两线段是否重合（斜率和端点匹配）"""
    (x1a, y1a), (x1b, y1b) = seg1
    (x2a, y2a), (x2b, y2b) = seg2
    slope1 = (y1b - y1a) / (x1b - x1a) if (x1b - x1a) != 0 else float('inf')
    slope2 = (y2b - y2a) / (x2b - x2a) if (x2b - x2a) != 0 else float('inf')
    return np.allclose([x1a, y1a, x1b, y1b], [x2a, y2a, x2b, y2b]) and np.isclose(slope1, slope2)

current_point = original_path[-1]  # 从最后一个点(32,4.1)开始
all_wrapped_points = []

for cycle in range(params['max_cycles']):
    color = colors[cycle]
    
    # --- 生成下一段 ---
    next_x = width if current_point[0] == 0 else 0
    next_y = current_point[1] - d
    next_point = (next_x, next_y)
    
    # --- 边界检查 ---
    if next_y < 0:
        # 计算交点
        k = (next_y - current_point[1]) / (next_x - current_point[0])
        x_int = current_point[0] - current_point[1] / k
        intersection = (x_int, 0)
        
        # 保留矩形内部分
        plt.plot([current_point[0], x_int], [current_point[1], 0], 
                 '-', color=color, lw=3, zorder=3)
        
        # 传送超出部分
        wrapped_point = (next_x, next_y + length)
        plt.plot([x_int, wrapped_point[0]], [length, wrapped_point[1]], 
                 '--', color=color, lw=2, zorder=4)
        
        # 记录传送点
        all_wrapped_points.append(wrapped_point)
        print(f"Cycle {cycle+1}: Wrapped point at {wrapped_point}")
        
        # 检查是否与原始折线重合
        new_segment = (current_point, intersection)
        for i in range(len(original_path)-1):
            orig_segment = (original_path[i], original_path[i+1])
            if segments_congruent(new_segment, orig_segment):
                print("Termination: Overlap with original path!")
                plt.plot([x_int, wrapped_point[0]], [length, wrapped_point[1]], 
                         '--', color=color, lw=2, zorder=4, 
                         label=f'Cycle {cycle+1} (Terminated)')
                break
        else:
            current_point = wrapped_point
            continue
        break
    else:
        plt.plot([current_point[0], next_x], [current_point[1], next_y], 
                 '-', color=color, lw=3, zorder=3)
        
        # 检查是否与原始折线重合
        new_segment = (current_point, next_point)
        for i in range(len(original_path)-1):
            if segments_congruent(new_segment, (original_path[i], original_path[i+1])):
                print("Termination: Overlap with original path!")
                break
        else:
            current_point = next_point
            continue
        break

# ===== 标注传送点 =====
for i, point in enumerate(all_wrapped_points):
    plt.scatter(*point, s=100, facecolor='none', edgecolor=colors[i], 
                linewidth=2, zorder=5)
    plt.text(point[0]+2, point[1], f'W{i+1}({point[0]:.1f},{point[1]:.1f})', 
             fontsize=9, ha='left', va='center')

# ===== 图例和样式 =====
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))
plt.legend(by_label.values(), by_label.keys(), loc='upper left', bbox_to_anchor=(1.05, 1))
plt.tight_layout()
plt.subplots_adjust(right=0.8)
plt.show()