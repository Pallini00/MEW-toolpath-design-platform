
import math
import matplotlib.pyplot as plt

# Function to calculate the distance between two points
def distance(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

# Function to filter points based on a minimum distance
def filter_points(points, min_distance):
    filtered_points = []
    for point in points:
        if all(distance(point, existing_point) > min_distance for existing_point in filtered_points):
            filtered_points.append(point)
    return filtered_points

# Function to read the points from a text file
def read_point_cloud(file_path):
    points = []
    with open(file_path, 'r') as file:
        for line in file:
            x, y = map(float, line.split())
            points.append((x, y))
    return points
# Function to save filtered points to a new file
def save_filtered_points(filtered_points, output_file):
    with open(output_file, 'w') as file:
        for point in filtered_points:
            file.write(f"{point[0]} {point[1]}\n")
# Read points from 'p.txt'
file_path = 'point_cloud_zong.txt'  # Replace with the path to your actual file
points = read_point_cloud(file_path)
file_path2 = 'point_cloud_new.txt'  # Replace with the path to your actual file
points2 = read_point_cloud(file_path2)
# Filter points so that the distance between any two points is greater than 1
min_distance = 1.0
filtered_points = filter_points(points, min_distance)
filtered_points2 = filter_points(points2, min_distance)
# Save filtered points to a new file
output_file = 'filtered_points_zogng.txt'  # Replace with the desired output file name
output_file2 = 'filtered_points_zogng2.txt'  # Replace with the desired output file name
save_filtered_points(filtered_points, output_file)
save_filtered_points(filtered_points2, output_file2)
# Separate the filtered points into x and y coordinates for plotting
x_values, y_values = zip(*filtered_points)

# Plotting the filtered points
#plt.scatter(x_values, y_values, color='blue', marker='o')
x_values, y_values = zip(*filtered_points2)
plt.scatter(x_values, y_values, color='red', marker='o')
# Adding labels and title
plt.xlabel('X Coordinates')
plt.ylabel('Y Coordinates')
plt.title('Filtered Point Cloud Plot (Distance > 1)')

# Display the plot
plt.show()
