import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
from scipy.interpolate import PchipInterpolator

# Function to find the intersection point considering the offset
def find_intersection(x0, offset, function):
    def line(x):
        return x - offset
    def difference(x):
        return function(x) - line(x)
    intersection = fsolve(difference, x0)[0]
    return intersection

# Function to calculate Euclidean distance between two points
def distance(p1, p2):
    return np.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)
# Function to generate points with distance 1 to 1.5
def generate_points(x_vals, y_vals):
    points = []
    for i in range(len(x_vals) - 1):
        p1 = (x_vals[i], y_vals[i])
        p2 = (x_vals[i + 1], y_vals[i + 1])
        dist = distance(p1, p2)

        # If distance between consecutive points is greater than 1.5, insert additional points
        while dist > 1.5:
            mid_x = (p1[0] + p2[0]) / 2
            mid_y = (p1[1] + p2[1]) / 2
            x_vals = np.insert(x_vals, i + 1, mid_x)
            y_vals = np.insert(y_vals, i + 1, mid_y)
            p2 = (mid_x, mid_y)
            dist = distance(p1, p2)

        points.append(p1)

    points.append((x_vals[-1], y_vals[-1]))
    return points

def add_intermediate_points(p1, p2):
    points = [p1]
    dist = distance(p1, p2)
    
    # 计算 p1 到 p2 之间的方向向量
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    total_distance = distance(p1, p2)
    
    # 当前点的位置
    current_x, current_y = p1

    # 按 1 到 1.5 的步长插入点
    while dist > 1:
        step = np.random.uniform(1, 1.5)  # 生成一个随机步长
        ratio = step / total_distance  # 计算移动比例

        # 更新当前点位置
        new_x = current_x + ratio * dx
        new_y = current_y + ratio * dy

        # 插入新的点
        points.append((new_x, new_y))

        # 更新当前点和剩余距离
        current_x, current_y = new_x, new_y
        dist = distance((current_x, current_y), p2)

    # 添加最后一个点 p2
    points.append(p2)
    
    return points


# Main function
def main():
    expression = input("Enter the function expression for L (example: '0.5*np.sin(x/10+y/100)+1'): ")
    w_expression = input("Enter the function expression for W (example: 'np.sin(y/50) + np.sin(x)+1.5'): ")
    n = int(input("Enter the number of rows to generate: "))
    k = int(input("Enter the number of points to find for each row: "))

    def dynamic_func(x, y):
        return eval(expression)

    def w_function(x, y):
        return eval(w_expression)

    # 输出 W 函数用于展示
    print(f"Using W(x, y) function: {w_expression}")

    # 存储所有的x控制点，用于设置x轴范围
    all_points = []  # 用于保存所有的点云
    zong_points = []  # 用于保存所有的点云
    all_x_points = []
    upper_points_per_row = []
    lower_points_per_row = []

    # 设置画布
    plt.figure(figsize=(10, 8))

    # 针对每一行生成曲线
    for r in range(1, n+1):
        row = r * 10  # y 值确定
        last_x = 0
        points = []
        lengths = []
        offsets = []

        for i in range(k):
            # 第一个点的offset为0
            if i == 0:
                offset = 0
            else:
                # 之后的offset是上一个交点 point_x + dynamic_func(point_x, row)
                offset = points[-1] + dynamic_func(points[-1], row)
            offsets.append(offset)

            # 找到函数和直线 y = x - offset 的交点
            point_x = find_intersection(last_x, offset, lambda x: dynamic_func(x, row))
            points.append(point_x)

            # 计算L值为当前点与上一个点的x距离
            length = point_x - last_x if i > 0 else point_x
            lengths.append(length)
            last_x = point_x

        # 生成上下对称的两条曲线
        group1_points = []
        group2_points = []
        for i, L in enumerate(lengths):
            x = points[i]
            W = w_function(x, row)  # 使用输入的 W(x, y) 函数计算宽度
            
            # 上下两组控制点
            group1_points.append((x, row + W))  # 上方曲线，y = row + W
            group2_points.append((x, row - W))  # 下方曲线，y = row - W

        # 将当前行的 upper 和 lower 控制点存储起来
        upper_points_per_row.append(group1_points)
        lower_points_per_row.append(group2_points)

        # 记录所有的x控制点
        all_x_points.extend([p[0] for p in group1_points])
        all_x_points.extend([p[0] for p in group2_points])

        # 使用 PCHIP 插值确保曲线通过控制点但较为平滑
        def pchip_interp_curve(points):
            points = np.array(points)
            x = points[:, 0]
            y = points[:, 1]
            
            # 对 x 和 y 进行排序
            sorted_indices = np.argsort(x)
            x_sorted = x[sorted_indices]
            y_sorted = y[sorted_indices]

            x_new = np.linspace(x_sorted.min(), x_sorted.max(), 500)
            pchip = PchipInterpolator(x_sorted, y_sorted)  # PCHIP 插值
            y_new = pchip(x_new)
            return x_new, y_new

        # 对 group1_points 和 group2_points 分别进行 PCHIP 插值
        x_pchip1, y_pchip1 = pchip_interp_curve(group1_points)
        x_pchip2, y_pchip2 = pchip_interp_curve(group2_points)

        # 绘制拟合后的 PCHIP 插值曲线
        plt.plot(x_pchip1, y_pchip1, 'r', label=f'Upper Curve Row {row}' if row == 1 else "")
        plt.plot(x_pchip2, y_pchip2, 'b', label=f'Lower Curve Row {row}' if row == 1 else "")

        # 绘制控制点
        plt.scatter([p[0] for p in group1_points], [p[1] for p in group1_points], color='blue', label=f'Upper Control Points Row {row}' if row == 1 else "")
        plt.scatter([p[0] for p in group2_points], [p[1] for p in group2_points], color='blue', label=f'Lower Control Points Row {row}' if row == 1 else "")

        # 生成点云
        upper_cloud = generate_points(x_pchip1, y_pchip1)
        lower_cloud = generate_points(x_pchip2, y_pchip2)

        # 蛇形排列：奇数行从左到右生成lower，再生成upper；偶数行从右到左生成lower，再生成upper
  
        if(r>1):
            last_lower = all_points[-1]
            first_upper = lower_cloud[-1]
            intermediate_points = add_intermediate_points(last_lower, first_upper)
            all_points.extend(intermediate_points)
            
        all_points.extend(reversed(lower_cloud))
        last_lower = all_points[-1]
        first_upper = upper_cloud[0]
        intermediate_points = add_intermediate_points(last_lower, first_upper)
        all_points.extend(intermediate_points)
        all_points.extend(upper_cloud)

        # 画黑色的“0轴”直线
        plt.axhline(y=row, color='black', linestyle='--')

    # 保存点云到 txt 文件
    with open("point_cloud_new.txt", "w") as f:
        for point in all_points:
            f.write(f"{point[0]} {point[1]}\n")

    g=1;

    # 连接每行交替的 upper 和 lower 控制点
    for i in range(k):
        alternate_line_points = []
        for row in range(n):
            if(row>0):
                las = alternate_line_points[-1]
                now = lower_points_per_row[row][i]
                intermediate_points = add_intermediate_points(las, now)
                alternate_line_points.extend(intermediate_points)
                
            ll = lower_points_per_row[row][i]
            ff = upper_points_per_row[row][i]
            
            intermediate_points = add_intermediate_points(ll, ff)
            alternate_line_points.extend(intermediate_points)

        

        if(g==1):
            alternate_line_points.reverse()
        
        if(i==0):
            zong_points.extend(alternate_line_points)
        else:
            last_lower = zong_points[-1]
            first_upper = alternate_line_points[0]
            intermediate_points = add_intermediate_points(last_lower, first_upper)
            zong_points.extend(intermediate_points)
            zong_points.extend(alternate_line_points)
        g=g*-1

        # 绘制交替连接的线
        plt.plot(
            [p[0] for p in alternate_line_points],
            [p[1] for p in alternate_line_points],
            'g--', label="Alternating Upper-Lower Line" if i == 0 else ""
        )
    with open("point_cloud_zong.txt", "w") as f:
        for point in zong_points:
            f.write(f"{point[0]} {point[1]}\n")

    plt.xlim(min(all_x_points), max(all_x_points))
    plt.gca().set_aspect('equal', adjustable='box')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.title('Point Cloud with Alternating Upper-Lower Lines')
    plt.grid(True)
    plt.legend(loc='best')
    plt.show()

if __name__ == "__main__":
    main()
