import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

# 设置矩形尺寸
width = 32   # 宽度 (mm)，沿x轴
length = 22 * np.pi  # 长度 (mm)，沿y轴 ≈69.08

# 创建图形和坐标轴
fig, ax = plt.subplots(figsize=(10, 8))
plt.title('矩形折线图 (超出边界停止)', fontsize=14, fontweight='bold')
plt.grid(True, linestyle='--', alpha=0.7)

# 创建矩形补丁
rectangle = patches.Rectangle((0, 0), width, length, 
                             linewidth=2, edgecolor='#1f77b4',
                             facecolor='#aec7e8', alpha=0.8, zorder=2)
ax.add_patch(rectangle)

# 设置坐标轴范围和标签
ax.set_xlim(-15, width + 15)  # 扩大范围以显示超出边界的点
ax.set_ylim(-15, length + 15)
ax.set_xlabel('X (mm)', fontsize=12)
ax.set_ylabel('Y (mm)', fontsize=12)
ax.set_aspect('equal')

# 定义四个顶点坐标
vertices = [
    (0, 0),            # A
    (width, 0),        # B
    (width, length),   # C
    (0, length)        # D
]

# 顶点标签名称
labels = ['A', 'B', 'C', 'D']

# 绘制顶点并添加标签
for i, (x, y) in enumerate(vertices):
    plt.scatter(x, y, s=100, color='red', zorder=3)
    if i == 0:  # A
        label_x, label_y = x - 8, y - 8
        ha, va = 'right', 'top'
    elif i == 1:  # B
        label_x, label_y = x + 8, y - 8
        ha, va = 'left', 'top'
    elif i == 2:  # C
        label_x, label_y = x + 8, y + 8
        ha, va = 'left', 'bottom'
    else:  # D
        label_x, label_y = x - 8, y + 8
        ha, va = 'right', 'bottom'
    plt.text(label_x, label_y, f'{labels[i]}({x:.1f}, {y:.1f})', 
             fontsize=12, ha=ha, va=va)

# 设置折线参数
d = 9  # 初始距离 (mm) - 可修改为任意值
current_distance = d  # 当前累计距离
points = [vertices[3]]  # 从D点开始 (索引3)
side = 'right'  # 当前方向：向右(AD→BC)

# 生成折线点
while True:
    # 确定下一个点的位置
    if side == 'right':  # 从AD连接到BC
        next_x = width
        next_y = length - current_distance
        side = 'left'
    else:  # 从BC连接到AD
        next_x = 0
        next_y = length - current_distance
        side = 'right'
    
    # 添加点（无论是否超出边界）
    points.append((next_x, next_y))
    
    # 实时检测边界
    if next_y < 0 or next_y > length:
        break  # 立即终止
    
    # 更新距离
    current_distance += d

# 绘制折线
x_coords = [p[0] for p in points]
y_coords = [p[1] for p in points]
plt.plot(x_coords, y_coords, 'ro-', linewidth=2, markersize=8, zorder=4)

# 添加折线点标签
for i, (x, y) in enumerate(points):
    if i == 0:  # D点已标注
        continue
    
    # 标记越界点
    if y < 0 or y > length:
        plt.text(x, y, f'超出边界({x:.1f}, {y:.1f})', 
                 fontsize=9, ha='center', va='center',
                 bbox=dict(facecolor='yellow', alpha=0.8, boxstyle='round,pad=0.3'))
        plt.scatter(x, y, s=100, color='orange', zorder=5)
    else:
        # 正常点标签位置
        offset_x = -3 if x == 0 else 3
        ha = 'right' if x == 0 else 'left'
        plt.text(x + offset_x, y, f'({x:.1f}, {y:.1f})', 
                 fontsize=9, ha=ha, va='center')

# 标记关键点
plt.text(points[0][0]-5, points[0][1]+2, '起点', 
         fontsize=10, ha='right', va='bottom',
         bbox=dict(facecolor='lightgreen', alpha=0.8))
plt.text(points[-1][0], points[-1][1]-3, '终止点', 
         fontsize=10, ha='center', va='top',
         bbox=dict(facecolor='salmon', alpha=0.8))

# 显示图形
plt.tight_layout()
plt.show()