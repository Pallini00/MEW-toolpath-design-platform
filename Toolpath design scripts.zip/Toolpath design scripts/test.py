import numpy as np
import matplotlib.pyplot as plt
from intersecting_structure_generation import ps_intersect
from math import pi

def Path_fill(points, max_dis: float):
    def distance(p1, p2):
        return np.linalg.norm(p1 - p2)

    def interpolate(p1, p2, num_points):
        # 这里 p1, p2 都是形如 (2,) 的向量
        return np.linspace(p1, p2, num_points + 2)[1:-1]

    new_points = [points[0]]
    for i in range(1, len(points)):
        p1 = points[i - 1]
        p2 = points[i]
        dist = distance(p1, p2)
        if dist > max_dis:
            num_extra = int(np.ceil(dist / max_dis)) - 1
            new_points.extend(interpolate(p1, p2, num_extra))
        new_points.append(p2)
    return np.vstack(new_points)

# 1) 先拿到原始网格点
x0, y0 = ps_intersect(primary_sf=0.5,
                      secondary_sf=0.5,
                      theta=0,
                      grid_number=15,
                      side_offset=1,
                      secondary=True,
                      centralized=False,
                      rotation_angle=0)

# 2) 把它们拼成 (N,2) 的点阵
pts0 = np.column_stack((x0, y0))

# 3) 插值细化，保证相邻距离 ≤ max_dis
pts_filled = Path_fill(pts0, max_dis=0.1)
x_f, y_f = pts_filled[:, 0], pts_filled[:, 1]

# 4) 针对「新」的 x_f 重新算幅值衰减
left, right = 5, 8
amp = np.zeros_like(x_f)
inside = (x_f >= left) & (x_f < right)
amplitude = 0.5
amp[x_f < left] = amplitude
amp[inside] = amplitude * (1- (x_f[inside] - left) / (right - left))
# x_f >= right 时 amp 已经是 0

# 5) 叠加正弦形变
omega1 = 1
omega2 = 1
phase1 = pi
phase2 = pi/2
x_def = x_f + amp * np.sin(y_f * omega1+phase1)
y_def = y_f + amp * np.sin(x_f * omega2+phase2)

# 6) 可视化
plt.plot(x_def, y_def,color="black")
plt.axis('equal')
plt.show()

# 7) 生成SolidWorks兼容的TXT文件（添加Z=0）
# 将变形后的点组合成N×3数组（X,Y,Z=0）
#points_3d = np.column_stack((x_def, y_def, np.zeros_like(x_def)))* 100

# 将变形后的点组合成 N×3 数组（X, Y, Z=3）
points_3d = np.c_[x_def, y_def, np.full(len(x_def), 0)]
# 保存为TXT文件
np.savetxt(
    "deformed_curve_3d.txt",  # 文件名
    points_3d,               # 3D点数据
    delimiter=" ",           # 用空格分隔（SolidWorks要求）
    fmt="%.2f",             # 保留6位小数（可根据需要调整）
    header="",              # 无表头
    comments=""             # 无注释符
)

print("已成功生成包含Z=0坐标的SolidWorks兼容TXT文件：deformed_curve_3d.txt")