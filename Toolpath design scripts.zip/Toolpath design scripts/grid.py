import numpy as np
import matplotlib.pyplot as plt
from math import pi, sin, cos, tan

# ==================== 修改后的网格生成函数 ====================
def ps_intersect(
    primary_sf: float = 1,
    secondary_sf: float = 1,
    theta: float = 0,
    grid_number_x: int = 4,  # 主方向网格数
    grid_number_y: int = 4,  # 副方向网格数
    side_offset: float = 2,
    secondary: bool = True,
    centralized: bool = False,
    rotation_angle: float = 0
):
    """
    生成交叉网格结构的函数（支持非对称网格）
    - grid_number_x: 主方向线段数量
    - grid_number_y: 副方向线段数量
    """
    original_pts = np.array([0, 0]).reshape(1, 2)
    
    # 主方向生成（使用 grid_number_x）
    for i in range(int(grid_number_x / 2) + 1):
        x1 = 2 * i * primary_sf * tan(theta)
        y1 = 2 * i * primary_sf
        x2 = x1 + grid_number_y * secondary_sf + 2 * side_offset  # 副方向用 grid_number_y
        y2 = y1
        x3 = x2 + primary_sf * tan(theta)
        y3 = y2 + primary_sf
        x4 = x3 - grid_number_y * secondary_sf - 2 * side_offset
        y4 = y3
        cycle_ary = np.array([(x1, y1), (x2, y2), (x3, y3), (x4, y4)]).reshape(4, 2)
        original_pts = np.vstack((original_pts, cycle_ary))
    original_pts = original_pts[:-2, :]
    x0 = original_pts[-1, 0]
    y0 = original_pts[-1, 1]
    
    # 副方向生成（使用 grid_number_y）
    if secondary:
        for j in range(int(grid_number_y / 2) + 1):
            x1 = x0 - side_offset * (1 - sin(theta)) - 2 * j * secondary_sf
            y1 = y0 + side_offset * cos(theta)
            y2 = - side_offset * cos(theta)
            x2 = x1 - (y1 - y2) * tan(theta)
            x3 = x2 - secondary_sf
            y3 = y2
            x4 = x1 - secondary_sf
            y4 = y1
            cycle_ary = np.array([(x1, y1), (x2, y2), (x3, y3), (x4, y4)]).reshape(4, 2)
            original_pts = np.vstack((original_pts, cycle_ary))
    
    original_pts = original_pts[1:-2, :]
    original_pts_x = original_pts[:, 0]
    original_pts_y = original_pts[:, 1]
    
    if centralized:
        x_center = side_offset + grid_number_x / 2 * primary_sf * tan(theta) + grid_number_y / 2 * secondary_sf
        y_center = grid_number_x / 2 * primary_sf
        original_pts_x = original_pts[:, 0] - x_center
        original_pts_y = original_pts[:, 1] - y_center
    
    # 旋转处理
    original_pts_x, original_pts_y = (
        original_pts_x * cos(rotation_angle) - original_pts_y * sin(rotation_angle),
        original_pts_x * sin(rotation_angle) + original_pts_y * cos(rotation_angle)
    )
    return original_pts_x, original_pts_y

# ==================== 路径插值函数 ====================
def Path_fill(points, max_dis: float):
    """ 在路径点之间插入点，确保相邻点距离不超过max_dis """
    def distance(p1, p2):
        return np.linalg.norm(p1 - p2)

    def interpolate(p1, p2, num_points):
        return np.linspace(p1, p2, num_points + 2)[1:-1]

    new_points = [points[0]]
    for i in range(1, len(points)):
        p1 = points[i - 1]
        p2 = points[i]
        dist = distance(p1, p2)
        if dist > max_dis:
            num_extra = int(np.ceil(dist / max_dis)) - 1
            new_points.extend(interpolate(p1, p2, num_extra))
        new_points.append(p2)
    return np.vstack(new_points)

# ==================== 主程序 ====================
if __name__ == "__main__":
    # 1) 生成非对称网格 (7x3)
    x0, y0 = ps_intersect(
        primary_sf=0.5,
        secondary_sf=0.5,
        theta=0,
        grid_number_x=15,  # 主方向7条线段
        grid_number_y=10,   # 副方向3条线段
        side_offset=1,
        secondary=True,
        centralized=False,
        rotation_angle=0
    )

    # 2) 合并为点阵并插值细化
    pts0 = np.column_stack((x0, y0))
    pts_filled = Path_fill(pts0, max_dis=1)  # 确保相邻点距≤1
    x_f, y_f = pts_filled[:, 0], pts_filled[:, 1]

    # 3) 幅值衰减设置 (x∈[5,8)时线性衰减)
    left, right = 5, 8
    amp = np.zeros_like(x_f)
    inside = (x_f >= left) & (x_f < right)
    amplitude = 0.5
    amp[x_f < left] = amplitude
    amp[inside] = amplitude * (1 - (x_f[inside] - left) / (right - left))

    # 4) 正弦变形
    omega1, omega2 = 1, 1
    phase1, phase2 = pi, pi/2
    x_def = x_f + amp * np.sin(y_f * omega1 + phase1)
    y_def = y_f + amp * np.sin(x_f * omega2 + phase2)

    # 5) 可视化
    plt.figure(figsize=(10, 5))
    plt.subplot(121)
    plt.scatter(x0, y0, c='r', label='原始网格')
    plt.title("原始网格 (7×3)")
    plt.axis('equal')
    
    plt.subplot(122)
    plt.plot(x_def, y_def, label='变形后路径')
    plt.title("带正弦变形的路径")
    plt.axis('equal')
    plt.tight_layout()
    plt.show()

    # 6) 输出SolidWorks兼容文件 (Z=2, 放大100倍)
    points_3d = np.column_stack((x_def * 100, y_def * 100, np.full(len(x_def), 2)))
    np.savetxt(
        "deformed_curve_asymmetric_grid.txt",
        points_3d,
        delimiter=" ",
        fmt="%.2f",
        header="",
        comments=""
    )
    print("文件已保存: deformed_curve_asymmetric_grid.txt")