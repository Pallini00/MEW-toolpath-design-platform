import matplotlib.pyplot as plt
import numpy as np

# 设置坐标系
plt.figure(figsize=(12, 8))
ax = plt.gca()

# 移动坐标轴到中心位置
ax.spines['left'].set_position('zero')
ax.spines['bottom'].set_position('zero')
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')

# 反转x轴和y轴方向
ax.invert_xaxis()  # x轴正方向向左
ax.invert_yaxis()  # y轴正方向向下

# 显式标出原点O（红色大圆点）
plt.scatter(0, 0, color='red', s=100, zorder=5, label='Origin (0,0)')
plt.text(0.5, -0.5, 'O', fontsize=14, ha='center', va='center', color='red')

# 定义原有四个点
points = {
    'A': (25, 7.065),
    'B': (0, 7.065),
    'C': (25, 16.485),
    'D': (0, 16.485),
    'B1': (0, 14.13)  # 新增点B1
}

# 绘制所有点（包括新增的B1）
for label, (x, y) in points.items():
    plt.scatter(x, y, s=80, label=f'{label}({x}, {y})')
    # 调整标签位置避免重叠
    offset_x = -1 if x == 0 else 0.5  # 原点左侧的点向左偏移
    ha = 'right' if x == 0 else 'left'
    plt.text(x + offset_x, y, f' {label}', fontsize=12, ha=ha, va='center')

# 连接成矩形（A→B→D→C→A）
rect_order = ['A', 'B', 'D', 'C', 'A']
x_coords = [points[p][0] for p in rect_order]
y_coords = [points[p][1] for p in rect_order]
plt.plot(x_coords, y_coords, 'r-', linewidth=3, label='Rectangle')

# 定义矩形边界和周期高度
y_top, y_bottom = 7.065, 16.485
height = y_bottom - y_top  # 9.42

def mirror_and_wrap(p1, p2, mirror_y):
    """生成镜像线段并处理周期性边界"""
    segments = []
    
    # 1. 原始线段AB1（仅显示矩形内部分）
    x1, y1 = p1
    x2, y2 = p2
    if y_top <= y1 <= y_bottom and y_top <= y2 <= y_bottom:
        segments.append((p1, p2))
    
    # 2. 生成向下对称的镜像线段
    def mirror_point(x, y):
        return (x, 2 * mirror_y - y)
    
    p1_mirrored = mirror_point(*p1)
    p2_mirrored = mirror_point(*p2)
    
    # 3. 处理镜像线段的周期性边界
    def wrap_segment(seg):
        (x1, y1), (x2, y2) = seg
        segments_wrapped = []
        
        # 计算线段与矩形边界的交点
        t_values = [0, 1]  # 始终包括起点和终点
        
        # 与上边界的交点
        if (y1 < y_top and y2 > y_top) or (y1 > y_top and y2 < y_top):
            t = (y_top - y1)/(y2 - y1)
            if 0 <= t <= 1:
                t_values.append(t)
        
        # 与下边界的交点
        if (y1 < y_bottom and y2 > y_bottom) or (y1 > y_bottom and y2 < y_bottom):
            t = (y_bottom - y1)/(y2 - y1)
            if 0 <= t <= 1:
                t_values.append(t)
        
        t_values = sorted(list(set(t_values)))  # 去重并排序
        
        # 分段处理
        for i in range(len(t_values)-1):
            t_start = t_values[i]
            t_end = t_values[i+1]
            x_start = x1 + t_start*(x2 - x1)
            y_start = y1 + t_start*(y2 - y1)
            x_end = x1 + t_end*(x2 - x1)
            y_end = y1 + t_end*(y2 - y1)
            
            # 只保留在矩形内的部分
            if y_top <= y_start <= y_bottom and y_top <= y_end <= y_bottom:
                segments_wrapped.append(((x_start, y_start), (x_end, y_end)))
            # 处理超出部分
            elif y_end > y_bottom:
                # 从下边界穿出，从上边界进入
                t_int = (y_bottom - y1)/(y2 - y1)
                x_int = x1 + t_int*(x2 - x1)
                segments_wrapped.append(((x_start, y_start), (x_int, y_bottom)))
                segments_wrapped.append(((x_int, y_top), (x_end, y_end - height)))
            elif y_end < y_top:
                # 从上边界穿出，从下边界进入
                t_int = (y_top - y1)/(y2 - y1)
                x_int = x1 + t_int*(x2 - x1)
                segments_wrapped.append(((x_start, y_start), (x_int, y_top)))
                segments_wrapped.append(((x_int, y_bottom), (x_end, y_end + height)))
        
        return segments_wrapped
    
    mirrored_segment = (p2_mirrored, p1_mirrored)  # 注意这里交换了顺序以确保方向正确
    wrapped_segments = wrap_segment(mirrored_segment)
    segments.extend(wrapped_segments)
    
    return segments

# 生成AB1的镜像和周期性处理后的线段
all_segments = mirror_and_wrap(points['A'], points['B1'], mirror_y=14.13)

# 绘制所有线段
colors = ['blue', 'green']
line_styles = ['--', '-']
labels = ['Original AB1 (within rectangle)', 'Mirrored and Wrapped']

# 先绘制原始线段
if all_segments and len(all_segments[0]) == 2:
    (x1, y1), (x2, y2) = all_segments[0]
    plt.plot([x1, x2], [y1, y2], color=colors[0], linestyle=line_styles[0], 
             linewidth=2, label=labels[0])

# 再绘制镜像线段（绿色）
for i, segment in enumerate(all_segments[1:], start=1):
    (x1, y1), (x2, y2) = segment
    plt.plot([x1, x2], [y1, y2], color=colors[1], linestyle=line_styles[1], 
             linewidth=2, label=labels[1] if i == 1 else "")

# ========== 添加交点A1标注 ==========
A1 = (25, 11.775)
plt.scatter(A1[0], A1[1], s=80, color='purple', zorder=5, label=f'A1 ({A1[0]:.2f}, {A1[1]:.2f})')
plt.text(A1[0]+0.5, A1[1], 'A1', fontsize=12, ha='left', va='center')

# 设置坐标轴范围（确保所有内容可见）
plt.xlim(30, -5)  # x轴范围（左正右负）
plt.ylim(20, -2)  # y轴范围（下正上负）

# 坐标轴标签（明确方向标注）
plt.xlabel('X axis (positive ←)', labelpad=15, loc='left')
plt.ylabel('Y axis (positive ↓)', labelpad=15, loc='top')
plt.title('Mirroring with Intersection Point A1', pad=20)

# 加强坐标轴和网格显示
ax.axhline(0, color='black', linewidth=1.5)  # x轴
ax.axvline(0, color='black', linewidth=1.5)  # y轴
ax.grid(True, linestyle='--', alpha=0.7)

# 调整刻度显示
ax.set_xticks([-5, 0, 5, 10, 15, 20, 25, 30])
ax.set_yticks([0, 5, 7.065, 10, 14.13, 15, 16.485, 20])

plt.legend(loc='upper left', bbox_to_anchor=(1, 1))  # 图例放在右侧避免遮挡
plt.tight_layout()
plt.show()