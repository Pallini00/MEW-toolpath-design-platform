import numpy as np
from math import sin, cos, pi, sqrt

def arc(center_x: float, center_y: float, radius: float, start_angle: float, stop_angle: float, max_dis: float):
    """
    生成圆弧上的点列
    """
    pts_x = np.array([])
    pts_y = np.array([])
    pts_number = int(abs(radius * (stop_angle - start_angle) / max_dis))
    angle_increment = (stop_angle - start_angle) / pts_number
    for i in range(pts_number):
        pt_x = center_x + radius * cos(start_angle + i * angle_increment)
        pt_y = center_y + radius * sin(start_angle + i * angle_increment)
        pts_x = np.append(pts_x, pt_x)
        pts_y = np.append(pts_y, pt_y)
    return pts_x, pts_y

if __name__ == "__main__":
    side_offset = 2
    radius = 1
    grid_number = 10  # 圆弧的数量
    max_dis = 0.1    # 点之间的最大距离
    
    # 初始化点列
    pts_x = np.array([])
    pts_y = np.array([])
    
    # 只生成第一行圆弧（保持原始坐标不变）
    for j in range(grid_number):
        center_x = side_offset + (0.5 + j) * radius * sqrt(2)
        center_y = (-1) ** (j + 1) * radius * sqrt(2) / 2  # 第一行的y坐标计算方式不变
        start_angle = 3 / 4 * pi * (-1) ** j
        stop_angle = 1 / 4 * pi * (-1) ** j
        
        # 生成圆弧点列
        pts_quarter_circle_x, pts_quarter_circle_y = arc(center_x, center_y, radius, 
                                                        start_angle, stop_angle, max_dis)
        
        # 添加到总点列中
        pts_x = np.hstack((pts_x, pts_quarter_circle_x))
        pts_y = np.hstack((pts_y, pts_quarter_circle_y))
    
    # 合并x,y坐标（保持原始坐标不变）
    pts = np.column_stack((pts_x, pts_y))
    
    # 输出点列（格式：x y 3）
    for point in pts:
        print(f"{point[0]:.2f} {point[1]:.2f} 3")
    
    # 可选：绘制圆弧（验证结果）
    import matplotlib.pyplot as plt
    plt.plot(pts[:, 0], pts[:, 1], 'black', linewidth=1)
    plt.axis('equal')
    plt.show()