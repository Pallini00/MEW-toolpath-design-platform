import numpy as np
from matplotlib import pyplot as plt
from math import sin, cos, tan, sqrt, pi
a = 10
row_number = 16
#row_number一定是一个偶数的2倍！
col_number = 61
#col_number一定是一个6的倍数+1！
pts_single_x = np.array(0)
pts_single_y = np.array(0)
#定位旋转中心
center_x = row_number/4*(1.5*a+0.5*a*sqrt(3))+((col_number-1)/6-1)*(1.5*a+0.5*a*sqrt(3))+0.5*a
center_y = row_number/4*(1.5*a+1.5*a*sqrt(3))
#成形单元只包括一个点，只需要研究点的位置变化，y一直在跳跃，回程的时候改变一下x的变化方向
for i in range(row_number):
    for j in range(col_number):
        if i % 2 == 0:
            if j % 6 == 0:
                pt_x = (a + a * 0.5+ a * 0.5 * sqrt(3)) * j / 3+(i/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = a * 0.5 + 0.5*i * (1.5 * a + 1.5 * a * sqrt(3))
            elif j % 3 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * j / 3+(i/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = a + 0.5 * a * sqrt(3) + 0.5*i * (1.5 * a + 1.5 * a * sqrt(3))
            elif (j + 1) % 6 == 0:
                pt_x = (a + a * 0.5+ a * 0.5 * sqrt(3)) * (j + 1) / 3 - a * 0.5+(i/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = a * 0.5 + 0.5 * a * sqrt(3) + 0.5*i * (1.5 * a + 1.5 * a * sqrt(3))
            elif (j - 1) % 6 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (j - 1) / 3 + a+(i/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = a * 0.5 + 0.5*i * (1.5 * a + 1.5 * a * sqrt(3))
            elif (j + 2) % 6 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (j + 2) / 3 - a * 0.5 - a * 0.5 * sqrt(3)+(i/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = a + 0.5 * a * sqrt(3) + 0.5*i * (1.5 * a + 1.5 * a * sqrt(3))
            else:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (j - 2) / 3 + a * 1.5+(i/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = a * 0.5 + 0.5 * a * sqrt(3) +0.5*i * (1.5 * a + 1.5 * a * sqrt(3))
        else:
            if j % 6 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (col_number - j-1) / 3+((i-1)/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = (i+1)/2 * (1.5 * a + 1.5 * a * sqrt(3)) - a - 0.5 * a * sqrt(3)
            elif j % 3 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (col_number - j-1) / 3+((i-1)/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = (i+1)/2 * (1.5 * a + 1.5 * a * sqrt(3)) - 0.5 * a
            elif (j + 1) % 6 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (col_number - j - 2) / 3 + a+((i-1)/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = (i+1)/2 * (1.5 * a + 1.5 * a * sqrt(3)) - a - 0.5 * a * sqrt(3)
            elif (j - 1) % 6 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (col_number - j) / 3 - a * 0.5 * sqrt(3)+((i-1)/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = (i+1)/2 * (1.5 * a + 1.5 * a * sqrt(3)) - 0.5 * a - 0.5 * a * sqrt(3)
            elif (j + 2) % 6 == 0:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (col_number - j - 3) / 3 + a + a * 0.5 * sqrt(3)+((i-1)/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = (i+1)/2 * (1.5 * a + 1.5 * a * sqrt(3)) - 0.5 * a - 0.5 * a * sqrt(3)
            else:
                pt_x = (a + a * 0.5 + a * 0.5 * sqrt(3)) * (col_number - j + 1) / 3 - a * 0.5 - a * 0.5 * sqrt(3)+((i-1)/2)*(a + a * 0.5+ a * 0.5 * sqrt(3))
                pt_y = (i+1)/2 * (1.5 * a + 1.5 * a * sqrt(3)) - 0.5 * a
        pts_single_x = np.append(pts_single_x, pt_x)
        pts_single_y = np.append(pts_single_y, pt_y)
#原点移动至图形中心（一定在某八边形形中心），以便旋转。
pts_single_x = pts_single_x-center_x
pts_single_y = pts_single_y-center_y
#插入过渡点，避免过渡线影响内部结构
pt_insert_1_x = pts_single_x[-1]-col_number*sqrt(3)/4*a
pt_insert_1_y = pts_single_y[-1]
pt_insert_2_x = pt_insert_1_x
#逆时针旋转60°得到取向2
pts_single_x_rotated_1, pts_single_y_rotated_1 = pts_single_x*cos(pi/3)-pts_single_y*sin(pi/3),\
    pts_single_x*sin(pi/3)+pts_single_y*cos(pi/3)
pt_insert_2_y = pts_single_y_rotated_1[1]
#逆时针旋转120°得到取向3
pts_single_x_rotated_2, pts_single_y_rotated_2 = pts_single_x*cos(2*pi/3)-pts_single_y*sin(2*pi/3),\
    pts_single_x*sin(2*pi/3)+pts_single_y*cos(2*pi/3)
pt_insert_3_x = pts_single_x_rotated_1[-1]
pt_insert_3_y = pt_insert_2_y
pt_insert_4_x = pts_single_x_rotated_2[0]
pt_insert_4_y = pt_insert_3_y
#所有取向与过渡点拼接
pts_single_x = np.hstack((pts_single_x, np.array(pt_insert_1_x),np.array(pt_insert_2_x), pts_single_x_rotated_1, np.array(pt_insert_3_x), np.array(pt_insert_4_x), pts_single_x_rotated_2))
pts_single_y = np.hstack((pts_single_y, np.array(pt_insert_1_y), np.array(pt_insert_2_y), pts_single_y_rotated_1, np.array(pt_insert_3_y), np.array(pt_insert_4_y),pts_single_y_rotated_2))
plt.plot(pts_single_x, pts_single_y)
plt.axis('equal')
plt.show()