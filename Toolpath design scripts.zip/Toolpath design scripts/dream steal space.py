import numpy as np
from matplotlib import pyplot as plt
from math import sin, cos, tan, sqrt, pi
from intersecting_structure_generation import Path_fill, remove_adjacent_duplicates

a = 10
row_number = 12
# row_number =2(n+1)
col_number = 12
# col_number =2(m+1)
# 定位旋转中心
center_x = 2 * a * row_number / 2 + 2.5 * a * col_number / 2
center_y = sqrt(3) * a * row_number / 2 - 0.5 * sqrt(3) * a * col_number / 2
pts_single_x = np.array(0)
pts_single_y = np.array(0)
for i in range(row_number):
    for j in range(col_number):
        pt_1_x = 2 * a * i + 2.5 * a * j
        pt_1_y = sqrt(3) * a * i - 0.5 * sqrt(3) * a * j
        pt_2_x = pt_1_x + 2 * a
        pt_2_y = pt_1_y
        pts_single_x = np.append(pts_single_x, pt_1_x)
        pts_single_x = np.append(pts_single_x, pt_2_x)
        pts_single_y = np.append(pts_single_y, pt_1_y)
        pts_single_y = np.append(pts_single_y, pt_2_y)
    for k in range(col_number):
        pt_1_x = 2 * a * i + col_number * 2.5 * a - 2.5 * a * k
        pt_1_y = sqrt(3) * a * i + (-col_number + 2 + k) * 0.5 * sqrt(3) * a
        pt_2_x = pt_1_x - 2 * a
        pt_2_y = pt_1_y
        pts_single_x = np.append(pts_single_x, pt_1_x)
        pts_single_x = np.append(pts_single_x, pt_2_x)
        pts_single_y = np.append(pts_single_y, pt_1_y)
        pts_single_y = np.append(pts_single_y, pt_2_y)
pts_single_append_x = np.array([0])
pts_single_append_y = np.array([0])
#添加附加线条
for i in range(row_number):
    for j in range(col_number):
        if i % 2 == 0:
            pt_1_x = 2 * a * i + 2.5 * a * j + a
            pt_1_y = sqrt(3) * a * i - 0.5 * sqrt(3) * a * j
            pt_2_x = pt_1_x + 2 * a
            pt_2_y = pt_1_y
        else:
            pt_1_x = 2 * a * i + 2.5 * a * (col_number - j) + 1.5 * a
            pt_1_y = sqrt(3) * a * i - 0.5 * sqrt(3) * a * (col_number - j - 1)
            pt_2_x = pt_1_x - 2 * a
            pt_2_y = pt_1_y
        pts_single_append_x = np.append(pts_single_append_x, pt_1_x)
        pts_single_append_x = np.append(pts_single_append_x, pt_2_x)
        pts_single_append_y = np.append(pts_single_append_y, pt_1_y)
        pts_single_append_y = np.append(pts_single_append_y, pt_2_y)

# 原点移动至图形中心（一定在某六边形中心），以便旋转。
pts_single_x = pts_single_x - center_x
pts_single_y = pts_single_y - center_y
pts_single_append_x = pts_single_append_x - center_x
pts_single_append_y = pts_single_append_y - center_y
# 逆时针旋转60°得到取向2
pts_single_x_rotated_1, pts_single_y_rotated_1 = pts_single_x * cos(pi / 3) - pts_single_y * sin(pi / 3), \
                                                 pts_single_x * sin(pi / 3) + pts_single_y * cos(pi / 3)
# 逆时针旋转120°得到取向3
pts_single_x_rotated_2, pts_single_y_rotated_2 = pts_single_x * cos(2 * pi / 3) - pts_single_y * sin(2 * pi / 3), \
                                                 pts_single_x * sin(2 * pi / 3) + pts_single_y * cos(2 * pi / 3)
# 逆时针旋转60°得到取向2
pts_single_x_rotated_append_1, pts_single_y_rotated_append_1 = pts_single_append_x * cos(
    pi / 3) - pts_single_append_y * sin(pi / 3), \
                                                               pts_single_append_x * sin(
                                                                   pi / 3) + pts_single_append_y * cos(pi / 3)
# 逆时针旋转120°得到取向3
pts_single_x_rotated_append_2, pts_single_y_rotated_append_2 = pts_single_append_x * cos(
    2 * pi / 3) - pts_single_append_y * sin(2 * pi / 3), \
                                                               pts_single_append_x * sin(
                                                                   2 * pi / 3) + pts_single_append_y * cos(2 * pi / 3)

# 插入过渡点，避免过渡线影响内部结构
pt_insert_1_x = pts_single_x[0] - 2 * a
pt_insert_1_y = pts_single_y[-1]
pt_insert_2_x = pt_insert_1_x
pt_insert_2_y = pts_single_y_rotated_1[0]
pt_insert_3_x = pt_insert_1_x
pt_insert_3_y = pts_single_y_rotated_1[-1]
pt_insert_4_x = pt_insert_3_x
pt_insert_4_y = pts_single_y_rotated_2[0]
pt_insert_5_x = pts_single_append_x[0]
pt_insert_5_y = pts_single_y_rotated_2[-1]
pt_insert_6_x = pt_insert_5_x
pt_insert_6_y = pt_insert_5_y
pt_insert_7_x = pt_insert_1_x
pt_insert_7_y = pts_single_append_y[-1]
pt_insert_8_x = pt_insert_7_x
pt_insert_8_y = pts_single_y_rotated_append_1[0]
pt_insert_9_x = pt_insert_1_x
pt_insert_9_y = pts_single_y_rotated_append_1[-1]
pt_insert_10_x = pt_insert_9_x
pt_insert_10_y = pts_single_y_rotated_append_2[0]
pt_insert_11_x = pts_single_x[0]
pt_insert_11_y = pts_single_y_rotated_append_2[-1]
pt_insert_12_x = pt_insert_11_x
pt_insert_12_y = pt_insert_11_y


plt.scatter(pt_insert_11_x, pt_insert_11_y)
plt.scatter(pt_insert_12_x, pt_insert_12_y)
# plt.scatter(pt_insert_4_x, pt_insert_4_y)
pts_single_x = np.append(np.append(pts_single_x, pt_insert_1_x), pt_insert_2_x)
pts_single_y = np.append(np.append(pts_single_y, pt_insert_1_y), pt_insert_2_y)
pts_single_x_rotated_1 =  np.append(np.append(pts_single_x_rotated_1, pt_insert_3_x), pt_insert_4_x)
pts_single_y_rotated_1 =  np.append(np.append(pts_single_y_rotated_1, pt_insert_3_y), pt_insert_4_y)
pts_single_x_rotated_2 =  np.append(np.append(pts_single_x_rotated_2, pt_insert_5_x), pt_insert_6_x)
pts_single_y_rotated_2 =  np.append(np.append(pts_single_y_rotated_2, pt_insert_5_y), pt_insert_6_y)
pts_single_append_x = np.append(np.append(pts_single_append_x, pt_insert_7_x), pt_insert_8_x)
pts_single_append_y = np.append(np.append(pts_single_append_y, pt_insert_7_y), pt_insert_8_y)
pts_single_x_rotated_append_1 = np.append(np.append(pts_single_x_rotated_append_1, pt_insert_9_x), pt_insert_10_x)
pts_single_y_rotated_append_1 = np.append(np.append(pts_single_y_rotated_append_1, pt_insert_9_y), pt_insert_10_y)
pts_single_x_rotated_append_2 = np.append(np.append(pts_single_x_rotated_append_2, pt_insert_11_x), pt_insert_12_x)
pts_single_y_rotated_append_2 = np.append(np.append(pts_single_y_rotated_append_2, pt_insert_11_y), pt_insert_12_y)

pts_single_x = np.hstack((pts_single_x, pts_single_x_rotated_1, pts_single_x_rotated_2))
pts_single_y = np.hstack((pts_single_y, pts_single_y_rotated_1, pts_single_y_rotated_2))
pts_single_append_x = np.hstack((pts_single_append_x, pts_single_y_rotated_append_1))
pts_single_append_y = np.hstack((pts_single_append_y, pts_single_y_rotated_append_1))
plt.plot(pts_single_x, pts_single_y)
plt.axis('equal')
plt.show()
