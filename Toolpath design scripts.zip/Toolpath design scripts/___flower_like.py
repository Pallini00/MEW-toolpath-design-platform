import numpy as np
import matplotlib.pyplot as plt
from math import sqrt, pi
from circle_ary import arc  # 假设这是自定义的圆弧生成函数

# 基础参数设置
circle_number = 12  # 每行圆弧数量
side_offset = 5    # 边界偏移量
radius = 2          # 圆弧半径
alternate = sqrt(3) / 2 * radius  # 交错偏移量
row_dis = sqrt(3) * radius        # 行间距
max_dis = 0.1       # 圆弧细分精度

# 初始化点集
pts_x = np.array([])
pts_y = np.array([])

# 基础圆弧生成（仅保留第一层循环）
for i in range(int(circle_number / 2)):
    # 生成上行圆弧
    for j in range(circle_number):
        center_x = side_offset + (0.5 + j) * radius
        center_y = 2 * i * row_dis + (-1) ** (j + 1) * alternate
        start_angle = 2/3 * pi * (-1) ** j  # 动态计算起始角度
        stop_angle = 1/3 * pi * (-1) ** j   # 动态计算终止角度
        
        # 生成圆弧点
        arc_x, arc_y = arc(center_x, center_y, radius, 
                          start_angle, stop_angle, max_dis)
        pts_x = np.hstack((pts_x, arc_x))
        pts_y = np.hstack((pts_y, arc_y))
    
    # 生成下行圆弧（保留原始结构）
    for j in range(circle_number):
        center_x = side_offset + circle_number * radius - (0.5 + j) * radius
        center_y = (2 * i + 1) * row_dis + (-1) ** (j + 1) * alternate
        stop_angle = 2/3 * pi * (-1) ** j
        start_angle = 1/3 * pi * (-1) ** j
        
        arc_x, arc_y = arc(center_x, center_y, radius,
                          start_angle, stop_angle, max_dis)
        pts_x = np.hstack((pts_x, arc_x))
        pts_y = np.hstack((pts_y, arc_y))

# 直接绘制基础圆弧
plt.figure(figsize=(10, 10))
plt.plot(pts_x, pts_y, 'black', linewidth=1)
# plt.scatter(pts_x, pts_y, s=1, color='r')  # 显示路径点
plt.axis('equal')
plt.title("Basic Arc Pattern Without Rotation")
plt.grid(False)
plt.show()