##################################
# This file is to generate a specific mosaic
# pattern, with a hexagon surrounded by 6 triangles
import numpy as np
import matplotlib.pyplot as plt
from math import pi, sin, cos, tan, atan, sqrt
from intersecting_structure_generation import ps_intersect, Path_fill, remove_adjacent_duplicates
########################################################
# This section is to generate a diamond pattern (60°)
# with its diagonal line in the vertical direction.
a = 1 # variable, half of the side length of the hexagon.
primary_sf = sqrt(3)*a
secondary_sf = 2*a
side_offset = 3 #variable
theta = -30 / 180 * pi #constant
#grid_number is a variable
grid_number = 10 #variable
rotation_angle = 120 / 180 * pi #constant
intersect_x_single, intersect_y_single = ps_intersect(primary_sf=primary_sf, secondary_sf=secondary_sf,
                                                      side_offset=side_offset,
                                                      theta=theta, grid_number=grid_number, centralized=True,
                                                      rotation_angle=rotation_angle)
########################################################
# This section is to add a group of horizontal lines
# defined interstitial points
x_inter_1, y_inter_1 = grid_number / 2 * secondary_sf + 2 * side_offset, 0
x_inter_2, y_inter_2 = x_inter_1, grid_number / 2 * sqrt(3) * secondary_sf - 0.25 * sqrt(3) * secondary_sf
intersect_x_single = np.append(intersect_x_single, x_inter_1)
intersect_y_single = np.append(intersect_y_single, y_inter_1)
intersect_x_single = np.append(intersect_x_single, x_inter_2)
intersect_y_single = np.append(intersect_y_single, y_inter_2)
for i in range(int(grid_number)):
    x1, y1 = x_inter_2 - side_offset, y_inter_2 - 2*i * sqrt(3) / 2 * secondary_sf
    x2, y2 = -grid_number / 2 * secondary_sf - side_offset, y1
    x3, y3 = x2, y2 - sqrt(3) / 2 * secondary_sf
    x4, y4 = x1, y3
    horizontal_x = np.array([x1, x2, x3, x4])
    horizontal_y = np.array([y1, y2, y3, y4])
    intersect_x_single = np.hstack((intersect_x_single, horizontal_x))
    intersect_y_single = np.hstack((intersect_y_single, horizontal_y))
##########################################################
cycle_number = 1 #variable
intersect_x = intersect_x_single
intersect_y = intersect_y_single
for i in range(cycle_number - 1):
    intersect_x = np.append(intersect_x, intersect_x_single)
    intersect_y = np.append(intersect_y, intersect_y_single)
pts = np.column_stack((intersect_x, intersect_y))
pts = Path_fill(points=pts, max_dis=0.5)
pts = remove_adjacent_duplicates(pts)
plt.plot(pts[:, 0], pts[:, 1])
plt.axis('equal')
plt.show()
