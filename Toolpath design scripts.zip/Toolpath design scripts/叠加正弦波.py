import numpy as np
import matplotlib.pyplot as plt
from math import pi, sin, cos
def insert_points(points, m):
    new_points = [points[0]]  # 初始化新数组，包含第一个点

    for i in range(1, len(points)):
        p1, p2 = points[i - 1], points[i]
        distance = np.linalg.norm(p2 - p1)  # 计算两个点的距离

        if distance <= m:
            # 如果距离小于等于 m，则直接将第二个点添加到新数组
            new_points.append(p2)
        else:
            # 计算需要插入的点数
            num_points = int(distance // m)
            # 计算线性插值
            for j in range(1, num_points + 1):
                new_point = p1 + (p2 - p1) * (j * m / distance)
                new_points.append(new_point)
            # 添加第二个点
            new_points.append(p2)

    return np.array(new_points)

def remove_adjacent_duplicates(pts):
    if len(pts) == 0:
        return pts

    unique_pts = [pts[0]]

    for i in range(1, len(pts)):
        if not np.array_equal(pts[i], pts[i - 1]):
            unique_pts.append(pts[i])

    return np.array(unique_pts)

# 参数设置
num_rows = 20  # 行数
amplitudes = [0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135,0.135]  # 每行的振幅
vertical_spacing = 0.5 # 行之间的垂直间距
num_cycles = 10  # 每行的周期数
horizontal_range = 10  # 水平区间的范围
a=horizontal_range/num_cycles
#填充后相邻两点的距离
adjacent_distance = 0.07
#分段后每一段包含的点个数
seg_pts_number = int(a / adjacent_distance)
# 时间范围
t = np.linspace(0, num_cycles * 2 * np.pi, 400)  # 生成时间轴
cycle_number=2

# 初始化点列
all_points = []

# 生成多行正弦波并添加过渡段
for row in range(num_rows):
    # 当前行的垂直偏移
    vertical_offset = row * vertical_spacing

    # 当前行的正弦波
    y = amplitudes[row] * np.sin(t) + vertical_offset
    x = np.linspace(0, horizontal_range, len(y))  # 水平区间相同

    # 奇数行从左到右，偶数行从右到左
    if row % 2 == 0:  # 奇数行
        all_points.extend(zip(x, y))
    else:  # 偶数行
        all_points.extend(zip(x[::-1], y))

    # 添加过渡段到下一行
    if row < num_rows - 1:
        transition_x = [horizontal_range if row % 2 == 0 else 0] * 100  # 竖直过渡
        transition_y = np.linspace(vertical_offset, (row + 1) * vertical_spacing, 100)
        all_points.extend(zip(transition_x, transition_y))

# 将点列转换为numpy数组
all_points = np.array(all_points)
# 去除相邻重合点
all_points = remove_adjacent_duplicates(all_points)
# 将图形中心化
all_points[:, 0] -= horizontal_range /2-0.5*vertical_spacing # 水平中心化
all_points[:, 1] -= (num_rows - 1) * vertical_spacing / 2# 垂直中心化
#第一个过渡点，注意总过渡线段长度是a的偶数倍
insert_1_x = all_points[-1, 0]
insert_1_y = all_points[-1, 1]+vertical_spacing
#单取向的旋转角度
theta = pi / 2
#旋转矩阵
rotate_matrix = np.array([cos(theta), -sin(theta), sin(theta), cos(theta)]).reshape(2, 2)
#单取向旋转90°
all_points_rotated = np.dot(all_points, rotate_matrix)
#将单取向与过渡点1、旋转后的取向点列组合
all_points = np.concatenate((all_points, np.array([insert_1_x, insert_1_y]).reshape(1, 2), all_points_rotated), axis=0)
#为了回到初始点额外加三个过渡点，切记总过渡线段长度是a的偶数倍
insert_2_x = all_points[-1, 0] + 2 * vertical_spacing
insert_2_y = all_points[-1, 1]
insert_3_x = insert_2_x
insert_3_y = insert_2_y - (num_rows+1)  * vertical_spacing
insert_4_x = all_points[0, 0]
insert_4_y = insert_3_y
#2-3-4过渡点的合集
insert_ary_temp = np.array([insert_2_x, insert_2_y, insert_3_x, insert_3_y, insert_4_x, insert_4_y]).reshape(3, 2)
#将双取向点列与过渡点组合
all_points = np.concatenate((all_points, insert_ary_temp), axis=0)
#利用insert_points函数将端点式点列填充为密集式点列
all_points = insert_points(all_points, adjacent_distance)
pts = all_points
for i in range(cycle_number - 1):
    pts = np.concatenate((pts, all_points), axis=0)
# 绘制图形
plt.scatter(pts[:, 0], pts[:, 1], s=1)
plt.axis('equal')
plt.show()

# 输出最终点的坐标到文件
output_file = "original_points.txt"
with open(output_file, "w") as f:
    for x, y in zip(pts_x, pts_y):
        f.write(f"({x:.4f}, {y:.4f})\n")