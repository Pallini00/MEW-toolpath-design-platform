from intersecting_structure_generation import ps_intersect, remove_adjacent_duplicates, Path_fill
from math import pi, sqrt
import numpy as np
import matplotlib.pyplot as plt

# 规定几何参数
primary_sf = 0.5
secondary_sf =0.5
side_offset =1
theta = 0  # 注意theta不能是pi/2的奇数倍，包括-pi/2，否则会出错！！！
grid_number =60
rotation_angle = 30
# rotation_angle = -30/180*pi #正值为逆时针旋转，负值为顺时针旋转
pts_x_single, pts_y_single = ps_intersect(primary_sf=primary_sf, secondary_sf=secondary_sf,
                                          side_offset=side_offset,
                                          theta=theta, grid_number=grid_number,
                                          rotation_angle=rotation_angle)

cycle_number = 30  # 可变
# cycle_number 是周期数，不是层数，如只有主副方向，则层数=2*周期数，如有主副方向与主副对角线方向，则层数=4*层数
pts_x = pts_x_single
pts_y = pts_y_single
for i in range(cycle_number - 1):
    pts_x = np.append(pts_x, pts_x_single)
    pts_y = np.append(pts_y, pts_y_single)
pts = np.column_stack((pts_x, pts_y))
#pts = Path_fill(points=pts, max_dis=1)
pts = remove_adjacent_duplicates(pts)
plt.plot(pts[:, 0], pts[:, 1])
plt.axis('equal')
plt.show()
# 输出结果
for point in pts:
    print(f"{point[0] + 20:.2f} {point[1]:.2f} 8")  # 输出时x+23
