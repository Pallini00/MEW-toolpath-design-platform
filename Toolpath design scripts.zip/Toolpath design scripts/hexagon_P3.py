import numpy as np
from matplotlib import pyplot as plt
from math import sin, cos, tan, sqrt, pi
from intersecting_structure_generation import Path_fill, remove_adjacent_duplicates
a = 10
row_number = 10
#row_number一定是一个奇数的2倍！
col_number = 10
#col_number一定是一个奇数的2倍！
pts_single_x = np.array(0)
pts_single_y = np.array(0)
#定位旋转中心
center_x = col_number/2*sqrt(3)/2*a
center_y = 0.5*(row_number-1)*1.5*a
#成形单元只包括一个点，只需要研究点的位置变化，y一直在跳跃，回程的时候改变一下x的变化方向
for i in range(row_number):
    for j in range(col_number):
        if i%2 == 0:
            pt_x = 0.5*sqrt(3)*a*j
        else:
            pt_x = 0.5*a*sqrt(3)*col_number-0.5 * sqrt(3) * a * j
        pt_y = 0.25*a*(-1)**(i+j)+1.5*a*i
        pts_single_x = np.append(pts_single_x, pt_x)
        pts_single_y = np.append(pts_single_y, pt_y)
#原点移动至图形中心（一定在某六边形中心），以便旋转。
pts_single_x = pts_single_x-center_x
pts_single_y = pts_single_y-center_y
#插入过渡点，避免过渡线影响内部结构
pt_insert_1_x = pts_single_x[-1]-col_number*sqrt(3)/4*a
pt_insert_1_y = pts_single_y[-1]
pt_insert_2_x = pt_insert_1_x
#逆时针旋转60°得到取向2
pts_single_x_rotated_1, pts_single_y_rotated_1 = pts_single_x*cos(pi/3)-pts_single_y*sin(pi/3),\
    pts_single_x*sin(pi/3)+pts_single_y*cos(pi/3)
pt_insert_2_y = pts_single_y_rotated_1[1]
#逆时针旋转120°得到取向3
pts_single_x_rotated_2, pts_single_y_rotated_2 = pts_single_x*cos(2*pi/3)-pts_single_y*sin(2*pi/3),\
    pts_single_x*sin(2*pi/3)+pts_single_y*cos(2*pi/3)
pt_insert_3_x = pts_single_x_rotated_1[-1]
pt_insert_3_y = pt_insert_2_y
pt_insert_4_x = pts_single_x_rotated_2[0]
pt_insert_4_y = pt_insert_3_y
#所有取向与过渡点拼接
pts_single_x = np.hstack((pts_single_x, np.array(pt_insert_1_x),np.array(pt_insert_2_x), pts_single_x_rotated_1, np.array(pt_insert_3_x), np.array(pt_insert_4_x), pts_single_x_rotated_2))
pts_single_y = np.hstack((pts_single_y, np.array(pt_insert_1_y), np.array(pt_insert_2_y), pts_single_y_rotated_1, np.array(pt_insert_3_y), np.array(pt_insert_4_y),pts_single_y_rotated_2))

cycle_number = 1  # 可变
# cycle_number 是周期数，不是层数，层数=3*周期数
pts_x = pts_single_x
pts_y = pts_single_y
for i in range(cycle_number - 1):
    pts_x = np.append(pts_x, pts_single_x)
    pts_y = np.append(pts_y, pts_single_y)
pts = np.column_stack((pts_x, pts_y))
pts = Path_fill(points=pts, max_dis=1)
pts = remove_adjacent_duplicates(pts)
plt.plot(pts[:, 0], pts[:, 1])
plt.axis('equal')
plt.show()
