import numpy as np
from circle_ary import arc
from math import pi
import matplotlib.pyplot as plt

from intersecting_structure_generation import Path_fill, remove_adjacent_duplicates

radius = 5
pts_x_semi1, pts_y_semi1 = arc(center_x=0, center_y=0.5 * radius, radius=0.5 * radius, start_angle=-pi / 2,
                               stop_angle=pi / 2,
                               max_dis=0.1)
pts_x_semi2, pts_y_semi2 = arc(center_x=0, center_y=1.5 * radius, radius=0.5 * radius, start_angle=-pi / 2,
                               stop_angle=-3 / 2 * pi,
                               max_dis=0.1)
pts_x_circle, pts_y_circle = arc(center_x=0, center_y=radius, radius=radius, start_angle=pi / 2,
                                 stop_angle=-3 / 2 * pi,
                                 max_dis=0.1)

pts_x_single = np.hstack((pts_x_semi1, pts_x_semi2, pts_x_circle))
pts_y_single = np.hstack((pts_y_semi1, pts_y_semi2, pts_y_circle))
x1, y1 = 1.5*radius, 2*radius
x2, y2 = x1, 0
pts_x_single = np.append(pts_x_single, x1)
pts_x_single = np.append(pts_x_single, x2)
pts_y_single = np.append(pts_y_single, y1)
pts_y_single = np.append(pts_y_single, y2)
# !!! 默认“由远及近”，如需“由近及远”则使用下面一行语句反转点列顺序。
# pts_x_single, pts_y_single = np.flip(pts_x_single), np.flip(pts_y_single) # !!!Take care whether to use this line
pts_x = pts_x_single
pts_y = pts_y_single
cycle_number = 2  # variable
for i in range(cycle_number - 1):
    pts_x = np.append(pts_x, pts_x_single)
    pts_y = np.append(pts_y, pts_y_single)
pts = np.column_stack((pts_x, pts_y))
# 额外添加了初始点与结束点，这两点的顺序可以调整。
initial_pt = np.array([-radius, -radius]).reshape(1, 2)
end_pt = np.array([1.5*radius, 2 * radius]).reshape(1, 2)
pts = np.vstack((initial_pt, pts, end_pt))
pts = Path_fill(points=pts, max_dis=0.5)
pts = remove_adjacent_duplicates(pts)
plt.plot(pts[:, 0], pts[:, 1])
plt.axis('equal')
plt.show()
