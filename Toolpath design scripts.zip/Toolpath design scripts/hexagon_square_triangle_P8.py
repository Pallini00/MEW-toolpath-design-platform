import numpy as np
from matplotlib import pyplot as plt
from math import sin, cos, tan, sqrt, pi
from intersecting_structure_generation import Path_fill, remove_adjacent_duplicates
a = 10
row_number = 20
col_number = 10
pts_single_x = np.array(0)
pts_single_y = np.array(0)
# 定位旋转中心
center_x = (1+sqrt(3))*a*col_number/2+0.5*a
center_y = (1+0.5*sqrt(3))*a+(3+sqrt(3))*a*(row_number/4-1)/2
for i in range(row_number):
    if i%4 == 0:
        for j in range(col_number):
            pt_1_x = (1+sqrt(3))*a*j
            pt_1_y = (3+sqrt(3))*a*i/4
            pt_2_x = pt_1_x+a
            pt_2_y = pt_1_y
            pt_3_x = pt_2_x+0.5*sqrt(3)*a
            pt_3_y = pt_2_y+0.5*a
            pts_single_x = np.append(pts_single_x, pt_1_x)
            pts_single_x = np.append(pts_single_x, pt_2_x)
            pts_single_x = np.append(pts_single_x, pt_3_x)
            pts_single_y = np.append(pts_single_y, pt_1_y)
            pts_single_y = np.append(pts_single_y, pt_2_y)
            pts_single_y = np.append(pts_single_y, pt_3_y)
    elif i%4 == 1:
        for j in range(col_number):
            pt_1_x = (1 + sqrt(3)) * a *(col_number-j)+a-0.5*(1 + sqrt(3)) * a
            pt_1_y = (3+sqrt(3))*a*(i-1)/4+0.5*(sqrt(3)+1)*a
            pt_2_x = pt_1_x-a
            pt_2_y = pt_1_y
            pt_3_x = pt_2_x-0.5*sqrt(3)*a
            pt_3_y = pt_2_y-0.5*a
            pts_single_x = np.append(pts_single_x, pt_1_x)
            pts_single_x = np.append(pts_single_x, pt_2_x)
            pts_single_x = np.append(pts_single_x, pt_3_x)
            pts_single_y = np.append(pts_single_y, pt_1_y)
            pts_single_y = np.append(pts_single_y, pt_2_y)
            pts_single_y = np.append(pts_single_y, pt_3_y)
    elif i%4 == 2:
        for j in range(col_number):
            pt_1_x = (1 + sqrt(3)) * a * j +0.5*(sqrt(3)+1)*a
            pt_1_y = (3+sqrt(3))*a*(i-2)/4 +0.5*(sqrt(3)+1)*a+a
            pt_2_x = pt_1_x + a
            pt_2_y = pt_1_y
            pt_3_x = pt_2_x + 0.5 * sqrt(3) * a
            pt_3_y = pt_2_y + 0.5 * a
            pts_single_x = np.append(pts_single_x, pt_1_x)
            pts_single_x = np.append(pts_single_x, pt_2_x)
            pts_single_x = np.append(pts_single_x, pt_3_x)
            pts_single_y = np.append(pts_single_y, pt_1_y)
            pts_single_y = np.append(pts_single_y, pt_2_y)
            pts_single_y = np.append(pts_single_y, pt_3_y)
    elif i%4 ==3:
        for j in range(col_number):
            pt_1_x = (1 + sqrt(3)) * a *(col_number-j)+a
            pt_1_y = (3+sqrt(3))*a*(i-3)/4+(2+sqrt(3))*a
            pt_2_x = pt_1_x - a
            pt_2_y = pt_1_y
            pt_3_x = pt_2_x - 0.5 * sqrt(3) * a
            pt_3_y = pt_2_y - 0.5 * a
            pts_single_x = np.append(pts_single_x, pt_1_x)
            pts_single_x = np.append(pts_single_x, pt_2_x)
            pts_single_x = np.append(pts_single_x, pt_3_x)
            pts_single_y = np.append(pts_single_y, pt_1_y)
            pts_single_y = np.append(pts_single_y, pt_2_y)
            pts_single_y = np.append(pts_single_y, pt_3_y)
# 原点移动至图形中心（一定在某六边形中心），以便旋转。
pts_single_x = pts_single_x-center_x
pts_single_y = pts_single_y-center_y
#逆时针旋转60°得到取向2
pts_single_x_rotated_1, pts_single_y_rotated_1 = pts_single_x*cos(pi/3)-pts_single_y*sin(pi/3),\
    pts_single_x*sin(pi/3)+pts_single_y*cos(pi/3)
#逆时针旋转120°得到取向3
pts_single_x_rotated_2, pts_single_y_rotated_2 = pts_single_x*cos(2*pi/3)-pts_single_y*sin(2*pi/3),\
    pts_single_x*sin(2*pi/3)+pts_single_y*cos(2*pi/3)
############################
# plt.plot(pts_single_x, pts_single_y)
############################
#插入过渡点，避免过渡线影响内部结构
pt_insert_1_x = pts_single_x[-1]-2*(1 + sqrt(3)) * a
pt_insert_1_y = pts_single_y[-1]
pt_insert_2_x = pt_insert_1_x
pt_insert_2_y = pts_single_y_rotated_1[0]
pt_insert_3_x = pt_insert_2_x
pt_insert_3_y = pt_insert_2_y
pt_insert_4_x = pts_single_x_rotated_2[0]
pt_insert_4_y = pt_insert_2_y
pt_insert_5_x = pts_single_x[0]
pt_insert_5_y = pts_single_y_rotated_2[-1]
pt_insert_6_x = pts_single_x[0]
pt_insert_6_y = pts_single_y[0]
pts_single_x = np.append(np.append(pts_single_x, pt_insert_1_x), pt_insert_2_x)
pts_single_y= np.append(np.append(pts_single_y, pt_insert_1_y), pt_insert_2_y)
pts_single_x_rotated_1 = np.append(np.append(pts_single_x_rotated_1, pt_insert_3_x), pt_insert_4_x)
pts_single_y_rotated_1 = np.append(np.append(pts_single_y_rotated_1, pt_insert_3_y), pt_insert_4_y)
pts_single_x_rotated_2 = np.append(np.append(pts_single_x_rotated_2, pt_insert_5_x), pt_insert_6_x)
pts_single_y_rotated_2 = np.append(np.append(pts_single_y_rotated_2, pt_insert_5_y), pt_insert_6_y)
pts_single_x = np.hstack((pts_single_x, pts_single_x_rotated_1, pts_single_x_rotated_2))
pts_single_y = np.hstack((pts_single_y, pts_single_y_rotated_1, pts_single_y_rotated_2))
cycle_number = 2  # 可变
# cycle_number 是周期数，不是层数，层数=3*周期数
pts_x = pts_single_x
pts_y = pts_single_y
for i in range(cycle_number - 1):
    pts_x = np.append(pts_x, pts_single_x)
    pts_y = np.append(pts_y, pts_single_y)
pts = np.column_stack((pts_x, pts_y))
pts = Path_fill(points=pts, max_dis=1)
pts = remove_adjacent_duplicates(pts)
plt.plot(pts[:, 0], pts[:, 1])
plt.axis('equal')
plt.show()



