import numpy as np
import matplotlib.pyplot as plt
from matplotlib.path import Path
import matplotlib.animation as animation

# ==========================
# 0. 大网格初始化
# ==========================
n = 300
x_vals = np.linspace(-50, 50, n)
y_vals = np.linspace(-35, 50, n)
X, Y = np.meshgrid(x_vals, y_vals, indexing='xy')  # 生成网格坐标

# 展平为一维数组
pts_x = X.flatten()
pts_y = Y.flatten()

# ===========================================================
# 1. 花瓣旋涡 (中心可调)
# ===========================================================
swirl_cx, swirl_cy = 0, 25  # 旋涡中心坐标

# 局部坐标转换
Xs = pts_x - swirl_cx
Ys = pts_y - swirl_cy
r_swirl = np.sqrt(Xs**2 + Ys**2)
theta_swirl = np.arctan2(Ys, Xs)

# 定义花瓣形状(6瓣)
flower_shape = 0.5 + 0.5 * np.cos(6 * theta_swirl)
r1 = 4 + 4 * flower_shape  # 内边界
r2 = r1 + 20               # 外边界

# 计算alpha权重(用于混合变形)
alpha_swirl = np.zeros_like(r_swirl)
mask_in = (r_swirl <= r1)
mask_out = (r_swirl >= r2)
alpha_swirl[mask_in] = 1
mid = ~mask_in & ~mask_out  # 过渡区域
alpha_swirl[mid] = 0.5 * (1 + np.cos(np.pi * (r_swirl[mid]-r1[mid]) / (r2[mid]-r1[mid])))

# 应用旋涡变形参数
A_swirl, B_swirl = 0.8, 0.12
C_swirl, D_swirl = 1.2, 0.4
r_swirl_prime = r_swirl * (1 + A_swirl * alpha_swirl * np.exp(-B_swirl * r_swirl))
theta_swirl_prime = theta_swirl + C_swirl * alpha_swirl * np.exp(-D_swirl * r_swirl)

# 转换回笛卡尔坐标
x_swirl = r_swirl_prime * np.cos(theta_swirl_prime) + swirl_cx
y_swirl = r_swirl_prime * np.sin(theta_swirl_prime) + swirl_cy

# ===========================================================
# 2. 经典心形 + 波纹
# ===========================================================
heart_cx, heart_cy = 0, -10  # 心形中心
heart_size = 0.5

# 生成心形参数方程
t = np.linspace(0, 2*np.pi, 1000)
heart_x_param = 16 * (np.sin(t))**3
heart_y_param = 13*np.cos(t) - 5*np.cos(2*t) - 2*np.cos(3*t) - np.cos(4*t)
heart_x_param = heart_size * heart_x_param + heart_cx  # 平移
heart_y_param = heart_size * heart_y_param + heart_cy

# 创建心形多边形Path对象
heart_poly = np.column_stack((heart_x_param, heart_y_param))
heart_path = Path(heart_poly, closed=True)
in_heart = heart_path.contains_points(np.column_stack((X.flatten(), Y.flatten()))).reshape(X.shape)

# 计算到边界的最近距离
dists = np.full(pts_x.shape, np.inf)
for i in range(len(heart_poly)-1):
    p1 = heart_poly[i]
    p2 = heart_poly[i+1]
    vec = p2 - p1
    vec_norm = np.dot(vec, vec)
    w = np.column_stack((pts_x - p1[0], pts_y - p1[1]))
    proj = np.clip(np.dot(w, vec) / vec_norm, 0, 1)
    closest = p1 + proj[:, None] * vec
    d = np.linalg.norm(np.column_stack((pts_x, pts_y)) - closest, axis=1)
    dists = np.minimum(dists, d)

# 计算心形区域的alpha权重
D = 10  # 过渡距离
raw_mask = in_heart.flatten()
alpha_heart = np.zeros_like(raw_mask, dtype=float)
alpha_heart[raw_mask] = 1.0
transition_zone = (dists <= D) & ~raw_mask
alpha_heart[transition_zone] = 0.5 * (1 + np.cos(np.pi * dists[transition_zone] / D))

# 波纹变形参数
A_wave, B_wave = 0.3, 1.1
C_wave, D_wave = 0.3, 1.1
x_wave = A_wave * np.sin(X) * np.cos(Y) + B_wave * X
y_wave = C_wave * np.cos(X) * np.sin(Y) + D_wave * Y
x_wave_1d = x_wave.flatten()
y_wave_1d = y_wave.flatten()

# ===========================================================
# 3. 六边形角度扰动
# ===========================================================
hex_cx, hex_cy = -30, 7.5  # 六边形中心
X_hex = pts_x - hex_cx
Y_hex = pts_y - hex_cy
r_hex = np.sqrt(X_hex**2 + Y_hex**2)
theta_hex = np.arctan2(Y_hex, X_hex)

angle_hex = np.abs(np.mod(theta_hex, np.pi/3) - np.pi/6)
hex_radius = 12 / np.cos(angle_hex)
r1_hex = hex_radius * 0.6
r2_hex = r1_hex + 12

# 计算六边形alpha权重
alpha_hex = np.zeros_like(r_hex)
in_hex = (r_hex <= r1_hex)
out_hex = (r_hex >= r2_hex)
mid_hex = ~in_hex & ~out_hex
alpha_hex[in_hex] = 1.0
alpha_hex[mid_hex] = 0.5 * (1 + np.cos(np.pi * (r_hex[mid_hex]-r1_hex[mid_hex])) / (r2_hex[mid_hex]-r1_hex[mid_hex]))

# 应用六边形扰动
A_hex = 0.15
k_hex = 6
r_hex_prime = r_hex * (1 + alpha_hex * A_hex * np.cos(k_hex * theta_hex))
x_hex = r_hex_prime * np.cos(theta_hex) + hex_cx
y_hex = r_hex_prime * np.sin(theta_hex) + hex_cy

# ===========================================================
# 4. 玫瑰花边界扰动
# ===========================================================
rose_cx, rose_cy = 30, 7.5  # 玫瑰花中心
X_rose = pts_x - rose_cx
Y_rose = pts_y - rose_cy
r_rose = np.sqrt(X_rose**2 + Y_rose**2)
theta_rose = np.arctan2(Y_rose, X_rose)

k_flower = 6
flower_radius = 15 * (1 + 0.4 * np.cos(k_flower * theta_rose))
r1_rose = flower_radius * 0.5
r2_rose = r1_rose + 10

# 计算玫瑰花alpha权重
alpha_rose = np.zeros_like(r_rose)
in_rose = (r_rose <= r1_rose)
out_rose = (r_rose >= r2_rose)
mid_rose = ~in_rose & ~out_rose
alpha_rose[in_rose] = 1.0
alpha_rose[mid_rose] = 0.5 * (1 + np.cos(np.pi * (r_rose[mid_rose]-r1_rose[mid_rose]) / (r2_rose[mid_rose]-r1_rose[mid_rose])))

# 应用玫瑰花扰动
A_rose = 0.015
k_rose = 3
r_rose_prime = r_rose * (1 + alpha_rose * A_rose * np.cos(k_rose * r_rose))
x_rose = r_rose_prime * np.cos(theta_rose) + rose_cx
y_rose = r_rose_prime * np.sin(theta_rose) + rose_cy

# ===========================================================
# 5. 合并所有变形
# ===========================================================
x_final = (
    pts_x
    + alpha_swirl * (x_swirl - pts_x)
    + alpha_heart * (x_wave_1d - pts_x)
    + alpha_hex * (x_hex - pts_x)
    + alpha_rose * (x_rose - pts_x)
)

y_final = (
    pts_y
    + alpha_swirl * (y_swirl - pts_y)
    + alpha_heart * (y_wave_1d - pts_y)
    + alpha_hex * (y_hex - pts_y)
    + alpha_rose * (y_rose - pts_y)
)

# 重塑为网格
FinalX = x_final.reshape(n, n)
FinalY = y_final.reshape(n, n)

# ===========================================================
# 6. 绘制变形网格
# ===========================================================
# 等比例调整图案大小
scale_factor = 0.2 # 缩放因子，可以根据需要调整
pts_x = x_final * scale_factor
pts_y = y_final * scale_factor

# 整体平移调整
translation_x = 30 # 平移的x坐标
translation_y = 30  # 平移的y坐标
pts_x = pts_x + translation_x
pts_y = pts_y + translation_y

# plt.plot(pts_x, pts_y)
plt.scatter(pts_x, pts_y, s=1, color='blue')
plt.axis('equal')
plt.show()

# 输出最终点的坐标到文件
output_file = "original_points.txt"
with open(output_file, "w") as f:
    for x, y in zip(pts_x, pts_y):
        f.write(f"({x:.4f}, {y:.4f})\n")

# ===========================================================
# 7. 生成路径点（完整实现）
# ===========================================================
def is_far_enough(x, y, X_path, Y_path, d):
    """检查新点与路径中最后一个点的距离是否大于d"""
    if len(X_path) == 0:
        return True
    dx = X_path[-1] - x
    dy = Y_path[-1] - y
    return dx ** 2 + dy ** 2 > d ** 2


def switch_direction(current_dir):
    """切换蛇形路径方向"""
    return {'up': 'down', 'down': 'up', 'left': 'right', 'right': 'left'}[current_dir]


def generate_path(FinalX, FinalY, n, skip_line=2, skip_point=1, d=0):
    """完整路径生成逻辑"""
    X_path, Y_path = [], []

    # --- 第一阶段：列方向蛇形 ---
    direction = 'up'
    col_list = list(range(1, n - 1, skip_line))  # 对应MATLAB列号2到n-1
    start_r = np.nan

    for idx, col in enumerate(col_list):
        # 列内行遍历逻辑
        if np.isnan(start_r):
            if direction == 'up':
                rows = list(range(0, n, skip_point))
            else:
                rows = list(range(n - 1, -1, -skip_point))
        else:
            if direction == 'up':
                rows = list(range(int(start_r), n, skip_point))
            else:
                rows = list(range(int(start_r), -1, -skip_point))
            rows = [r for r in rows if 0 <= r < n]

        # 添加列内点
        for r in rows:
            x, y = FinalX[r, col], FinalY[r, col]
            if is_far_enough(x, y, X_path, Y_path, d):
                X_path.append(x)
                Y_path.append(y)

        # 横向过渡段
        if idx < len(col_list) - 1:
            next_col = col_list[idx + 1]
            step = 1 if next_col > col else -1
            for c in range(col + step, next_col + step, step * skip_point):
                if 0 <= c < n:
                    x, y = FinalX[rows[-1], c], FinalY[rows[-1], c]
                    if is_far_enough(x, y, X_path, Y_path, d):
                        X_path.append(x)
                        Y_path.append(y)
            start_r = rows[-1]

        direction = switch_direction(direction)

    # --- 第二阶段：行方向蛇形 ---
    final_row = rows[-1] if len(rows) > 0 else 0
    start_c = np.nan
    direction = 'left'

    # 确定行顺序
    if final_row == 0:
        row_order = list(range(1, n - 1, skip_line))  # 对应MATLAB第2行到n-1行
    else:
        row_order = list(range(n - 2, 0, -skip_line))  # 逆序

    for idx, row in enumerate(row_order):
        # 行内列遍历逻辑
        if np.isnan(start_c):
            if direction == 'left':
                cols = list(range(n - 1, -1, -skip_point))
            else:
                cols = list(range(0, n, skip_point))
        else:
            if direction == 'left':
                cols = list(range(int(start_c), -1, -skip_point))
            else:
                cols = list(range(int(start_c), n, skip_point))
            cols = [c for c in cols if 0 <= c < n]

        # 添加行内点
        for c in cols:
            x, y = FinalX[row, c], FinalY[row, c]
            if is_far_enough(x, y, X_path, Y_path, d):
                X_path.append(x)
                Y_path.append(y)

        # 垂直过渡段
        if idx < len(row_order) - 1:
            next_row = row_order[idx + 1]
            step = 1 if next_row > row else -1
            for r in range(row + step, next_row + step, step * skip_point):
                if 0 <= r < n:
                    x, y = FinalX[r, cols[-1]], FinalY[r, cols[-1]]
                    if is_far_enough(x, y, X_path, Y_path, d):
                        X_path.append(x)
                        Y_path.append(y)
            start_c = cols[-1]

        direction = switch_direction(direction)

    return X_path, Y_path


# 生成路径点
X_path, Y_path = generate_path(FinalX, FinalY, n)

# ===========================================================
# 8. 动态绘制（修复动画错误）
# ===========================================================
if len(X_path) == 0:
    print("错误：路径点为空！")
else:
    fig, ax = plt.subplots(figsize=(10, 8))
    ax.set(
        xlim=(-55, 55),
        ylim=(-40, 55),
        aspect='equal',
        title='动态蛇形路径绘制',
        adjustable='box'
    )

    # 初始化起点和终点
    ax.plot(X_path[0], Y_path[0], 'go', markersize=2, label='起点')
    ax.plot(X_path[-1], Y_path[-1], 'ro', markersize=2, label='终点')

    # 加速参数设置
    frame_step = 500  # 每次绘制5个点
    total_frames = len(X_path) // frame_step + 1


    # 动态绘制函数（优化性能）
    def animate(i):
        if i < len(X_path):
            ax.plot(X_path[i], Y_path[i], 'bo', markersize=0.5, alpha=0.3)
        return ax,


    # 创建动画（限制最大帧数）
    # ani = animation.FuncAnimation(
    #     fig, animate,
    #     frames=min(len(X_path), 5000),  # 限制5000帧防止内存溢出
    #     interval= 0.3,
    #     blit=True,
    #     repeat=False
    # )

    plt.legend()
    plt.show()