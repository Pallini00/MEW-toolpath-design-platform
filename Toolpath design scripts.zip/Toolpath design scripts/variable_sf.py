import numpy as np
import matplotlib.pyplot as plt


def variable_sf(primary_sfs, secondary_sfs, side_offset, layer_number):
    # 验证输入数组
    if len(primary_sfs) % 2 != 0:
        raise ValueError(f"primary_sfs的长度必须是偶数，当前长度为{len(primary_sfs)}")

    if len(secondary_sfs) % 2 != 0:
        raise ValueError(f"secondary_sfs的长度必须是偶数，当前长度为{len(secondary_sfs)}")

    if len(primary_sfs) != len(secondary_sfs):
        raise ValueError(
            f"primary_sfs和secondary_sfs的长度必须相等，当前长度分别为{len(primary_sfs)}和{len(secondary_sfs)}")

    # 继续原有代码
    primary_sfs = np.hstack([[0], primary_sfs, [0]])
    secondary_sfs = np.hstack([[0], secondary_sfs, [0]])
    pts_x = np.array([0])
    pts_y = np.array([0])
    cum_primary_sfs = np.cumsum(primary_sfs)
    height = cum_primary_sfs[-1]
    cum_secondary_sfs = np.cumsum(secondary_sfs)
    width = cum_secondary_sfs[-1]

    for layer in range(layer_number):
        for i in range(int(len(primary_sfs) / 2)):
            x1 = 0
            y1 = cum_primary_sfs[2 * i]
            x2 = 2 * side_offset + width
            y2 = y1
            x3 = x2
            y3 = y2 + primary_sfs[2 * i + 1]
            x4 = 0
            y4 = y3
            pts_x = np.hstack([pts_x, x1, x2, x3, x4])
            pts_y = np.hstack([pts_y, y1, y2, y3, y4])
        pts_x = pts_x[:-1]
        pts_y = pts_y[:-1]
        pts_x = np.append(pts_x, pts_x[-1])
        pts_y = np.append(pts_y, pts_y[-1] + side_offset)

        for i in range(int(len(secondary_sfs) / 2)):
            x1 = side_offset + width - cum_secondary_sfs[2 * i]
            y1 = height + side_offset
            x2 = x1
            y2 = -side_offset
            x3 = x1 - secondary_sfs[2 * i + 1]  # 这里应该是secondary_sfs而不是primary_sfs
            y3 = y2
            x4 = x3
            y4 = height + side_offset
            pts_x = np.hstack([pts_x, x1, x2, x3, x4])
            pts_y = np.hstack([pts_y, y1, y2, y3, y4])
        pts_x = pts_x[:-1]
        pts_y = pts_y[:-1]
        pts_x = np.append(pts_x, pts_x[-1] - side_offset)
        pts_y = np.append(pts_y, pts_y[-1])

    plt.plot(pts_x, pts_y)
    plt.grid(True)
    plt.axis('equal')
    plt.show()


if __name__ == '__main__':
    try:
        # 测试错误情况1: 长度不是偶数
        # primary_sfs = [1., 2., 3., 4, 5]  # 奇数长度
        # secondary_sfs = [1., 2., 3., 4., 5, 2]

        # 测试错误情况2: 长度不相等
        # primary_sfs = [1., 2., 3., 4, 5, 1]
        # secondary_sfs = [1., 2., 3., 4.]  # 长度不同

        # 正确情况
        primary_sfs = [1., 2., 3., 4,1,2]
        secondary_sfs = [1., 2., 3.,  2,4,2]

        side_offset = 1
        layer_number = 2
        variable_sf(primary_sfs, secondary_sfs, side_offset, layer_number)
    except ValueError as e:
        print(f"错误: {e}")