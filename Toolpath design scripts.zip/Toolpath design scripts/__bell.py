import numpy as np
import matplotlib.pyplot as plt
from math import sin, cos, tan, sqrt, pi
from circle_ary import arc
import numpy as np
from intersecting_structure_generation import remove_adjacent_duplicates, Path_fill

def rotate_points(pts, theta, center):
    """
    将n个点绕某一点旋转theta角度
    """
    cx, cy = center
    cos_theta = np.cos(theta)
    sin_theta = np.sin(theta)
    rotation_matrix = np.array([
        [cos_theta, -sin_theta],
        [sin_theta, cos_theta]
    ])
    translated_pts = pts - np.array([cx, cy])
    rotated_pts = translated_pts.dot(rotation_matrix.T)
    rotated_pts += np.array([cx, cy])
    return rotated_pts

# 参数设置
circle_number = 10
side_offset = 2
radius = 2
alternate = sqrt(3) / 2 * radius
row_dis = sqrt(3) * radius
max_dis = 0.1

# 生成初始结构
pts_x_single = np.array([-2])
pts_y_single = np.array([2])
for i in range(int(circle_number / 2)):
    for j in range(circle_number):
        center_x = side_offset + (0.5 + j) * radius
        center_y = 2 * i * row_dis + (-1) ** (j + 1) * alternate
        start_angle = 2 / 3 * pi * (-1) ** j
        stop_angle = 1 / 3 * pi * (-1) ** j
        arc_x, arc_y = arc(center_x, center_y, radius, start_angle,
                           stop_angle, max_dis)
        pts_x_single = np.hstack((pts_x_single, arc_x))
        pts_y_single = np.hstack((pts_y_single, arc_y))
    x1, y1 = pts_x_single[-1] + side_offset, pts_y_single[-1]
    x2, y2 = x1, y1 + row_dis
    pts_x_single = np.hstack((pts_x_single, [x1, x2]))
    pts_y_single = np.hstack((pts_y_single, [y1, y2]))
    for j in range(circle_number):
        center_x = side_offset + circle_number * radius - (0.5 + j) * radius
        center_y = (2 * i + 1) * row_dis + (-1) ** (j + 1) * alternate
        stop_angle = 2 / 3 * pi * (-1) ** j
        start_angle = 1 / 3 * pi * (-1) ** j
        arc_x, arc_y = arc(center_x, center_y, radius, start_angle,
                           stop_angle, max_dis)
        pts_x_single = np.hstack((pts_x_single, arc_x))
        pts_y_single = np.hstack((pts_y_single, arc_y))
    x1, y1 = pts_x_single[-1] - side_offset, pts_y_single[-1]
    x2, y2 = x1, y1 + row_dis
    pts_x_single = np.hstack((pts_x_single, [x1, x2]))
    pts_y_single = np.hstack((pts_y_single, [y1, y2]))

# 移除旋转部分，直接使用初始结构
pts_single = np.column_stack((pts_x_single, pts_y_single))

# 保留重复周期（cycle_number）
cycle_number = 1  # 可以调整
pts_x = pts_x_single
pts_y = pts_y_single
for i in range(cycle_number - 1):
    pts_x = np.append(pts_x, pts_x_single)
    pts_y = np.append(pts_y, pts_y_single)

pts = np.column_stack((pts_x, pts_y))
pts = Path_fill(points=pts, max_dis=0.5)
pts = remove_adjacent_duplicates(pts)

# 绘制
plt.plot(pts[:, 0], pts[:, 1],'black',linewidth=1)
plt.axis('equal')
plt.show()