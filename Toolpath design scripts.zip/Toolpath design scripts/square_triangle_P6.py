import numpy as np
from matplotlib import pyplot as plt
from math import sin, cos, tan, sqrt, pi
a = 10
row_number = 13
#row_number一定是一个8的倍数+1！
col_number = 20
#col_number一定是一个4的倍数+1！
pts_single_x = np.array(0)
pts_single_y = np.array(0)
#定位旋转中心
center_x = col_number/2*sqrt(3)/2*a
center_y = 0.5*(row_number-1)*1.5*a
#成形单元只包括一个点，只需要研究点的位置变化，y一直在跳跃，回程的时候改变一下x的变化方向
for j in range(col_number):
    for i in range(row_number):
        if j%2==0:
            if i%4==0 or i%4==3:
                pt_x = j/2*a+0.5*a
            else:
                pt_x =j/2*a
            pt_y = i*a
        else:
            if i%4==0 or i%4==1:
                pt_x = (j+1)/2 * a - 0.5 * a
            else:
                pt_x = (j+1)/2*a
            pt_y = (row_number-i-1)*a
        pts_single_x = np.append(pts_single_x, pt_x)
        pts_single_y = np.append(pts_single_y, pt_y)
for i in range(row_number):
    for j in range(col_number//2+1):
        if i%2==0:
            pt_x =j*a
        else:
            pt_x =((col_number//2+1)-j-1)*a
        pt_y =i*a
        pts_single_x = np.append(pts_single_x, pt_x)
        pts_single_y = np.append(pts_single_y, pt_y)
#原点移动至图形中心（一定在某八边形形中心），以便旋转。
pts_single_x = pts_single_x-center_x
pts_single_y = pts_single_y-center_y
#插入过渡点，避免过渡线影响内部结构
pt_insert_1_x = pts_single_x[-1]-col_number*sqrt(3)/4*a
pt_insert_1_y = pts_single_y[-1]
pt_insert_2_x = pt_insert_1_x
#所有取向与过渡点拼接
plt.plot(pts_single_x, pts_single_y)
plt.axis('equal')
plt.show()