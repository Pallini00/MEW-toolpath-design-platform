import numpy as np
import matplotlib.pyplot as plt
from intersecting_structure_generation import psdd_intersect, remove_adjacent_duplicates, Path_fill

# 设置圆的半径和圆心坐标
radius = 1
center = (0, 0)

# 生成圆的角度数据，范围从0到2pi
theta = np.linspace(0, 2 * np.pi, 100)

# 计算圆的x和y坐标
x = center[0] + radius * np.cos(theta)
y = center[1] + radius * np.sin(theta)

# 将x和y坐标合并为一个二维数组
pts = np.column_stack((x, y))
max_dis = 0.01

# 绘制圆的图像
pts = Path_fill(points=pts, max_dis=0.01)
pts = remove_adjacent_duplicates(pts)
plt.plot(pts[:, 0], pts[:, 1],color='black')
plt.axis('equal')
plt.show()

# 显示图片
plt.show()

# 输出结果
for point in pts:
    print(f"{point[0]:.2f} {point[1]:.2f} v")
