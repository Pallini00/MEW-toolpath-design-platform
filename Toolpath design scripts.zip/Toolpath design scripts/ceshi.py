import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
from matplotlib.colors import LinearSegmentedColormap

# ===== 用户可调参数 =====
params = {
    'd': 14.36864,         # y递减步长
    'width': 32,           # 矩形宽度
    'length': 69.08,       # 矩形长度
    'max_cycles': 10       # 最大循环次数
}

# ===== 初始化设置 =====
width, length, d = params['width'], params['length'], params['d']
segments_per_group = int(length // d) + 1  # 每组段数

# 创建扩展颜色池（使用彩虹色系，足够支持大量循环）
cmap = plt.get_cmap('rainbow')
colors = [cmap(i) for i in np.linspace(0, 1, max(20, params['max_cycles']))]

# 创建图形
fig, ax = plt.subplots(figsize=(14, 10))
plt.title(f'Toolpath (d={d}mm, {segments_per_group} segments/group)', 
         fontsize=14, pad=20)
rectangle = patches.Rectangle((0, 0), width, length, linewidth=2, 
                             edgecolor='black', facecolor='lightgray', alpha=0.1)
ax.add_patch(rectangle)
ax.set(xlim=(-2, width+2), ylim=(-2, length+2), aspect='equal')
plt.grid(True, linestyle=':', alpha=0.5)

# ===== 路径生成与颜色控制 =====
current_point = (0, length)  # 起始点
current_group = 0
current_segment_in_group = 0
legend_handles = []  # 用于图例

for cycle in range(params['max_cycles']):
    color = colors[current_group % len(colors)]
    
    # 只在第一次出现时添加图例
    if current_group < 5:  # 只显示前5组的图例
        legend_handles.append(
            plt.Line2D([], [], color=color, lw=1,
                      label=f'Group {current_group+1} ({segments_per_group} segments)')
        )
    
    while current_segment_in_group < segments_per_group:
        # 生成下一段
        next_x = width if current_point[0] == 0 else 0
        next_y = current_point[1] - d
        
        # 边界检查
        if next_y < 0:
            # 计算交点
            k = (next_y - current_point[1]) / (next_x - current_point[0])
            x_int = current_point[0] - current_point[1] / k
            
            # 绘制矩形内部分（当前组颜色）
            plt.plot([current_point[0], x_int], [current_point[1], 0],
                     '-', color=color, lw=1, zorder=3)
            
            # 传送部分（下一组颜色，使用实线）
            wrapped_point = (next_x, next_y + length)
            next_color = colors[(current_group + 1) % len(colors)]
            plt.plot([x_int, wrapped_point[0]], [length, wrapped_point[1]],
                     '-', color=next_color, lw=1, zorder=4)
            
            # 更新状态（仍计为1段）
            current_segment_in_group += 1
            current_point = wrapped_point
            break
        else:
            # 完整线段（当前组颜色）
            plt.plot([current_point[0], next_x], [current_point[1], next_y],
                     '-', color=color, lw=1, zorder=3)
            current_point = (next_x, next_y)
            current_segment_in_group += 1
    
    # 组切换检查
    if current_segment_in_group >= segments_per_group:
        current_group += 1
        current_segment_in_group = 0

# ===== 优化图例 =====
legend_handles.append(
    plt.Line2D([], [], color='gray', linestyle='-', lw=1, 
               label=f'Each group = {segments_per_group} segments')
)
plt.legend(handles=legend_handles, bbox_to_anchor=(1.05, 1), 
           fontsize=10, framealpha=0.9)
plt.tight_layout()
plt.subplots_adjust(right=0.85)

plt.show()