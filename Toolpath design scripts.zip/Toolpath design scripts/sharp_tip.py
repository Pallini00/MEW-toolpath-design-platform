import numpy as np
import matplotlib.pyplot as plt
from math import sin, cos, tan, sqrt, pi
from circle_ary import arc
import numpy as np
from intersecting_structure_generation import remove_adjacent_duplicates, Path_fill

def rotate_points(pts, theta, center):
    """
    将n个点绕某一点旋转theta角度

    参数:
    pts : numpy数组, 形状为(n, 2)，代表n个点
    theta : float, 旋转角度，单位为弧度
    center : 元组, 旋转中心点(cx, cy)

    返回:
    numpy数组, 形状为(n, 2)，旋转后的点
    """
    # 旋转中心
    cx, cy = center

    # 创建旋转矩阵
    cos_theta = np.cos(theta)
    sin_theta = np.sin(theta)
    rotation_matrix = np.array([
        [cos_theta, -sin_theta],
        [sin_theta, cos_theta]
    ])

    # 平移点使旋转中心到原点
    translated_pts = pts - np.array([cx, cy])

    # 应用旋转矩阵
    rotated_pts = translated_pts.dot(rotation_matrix.T)

    # 平移点回原位置
    rotated_pts += np.array([cx, cy])

    return rotated_pts
circle_number = 16
side_offset = 10
radius = 2
alternate = sqrt(3) / 2 * radius
row_dis = sqrt(3) * radius
max_dis = 0.1
pts_x_single = np.array([-2])
pts_y_single = np.array([2])
for i in range(int(circle_number / 2)):
    for j in range(circle_number):
        center_x = side_offset + (0.5 + j) * radius
        center_y = 2 * i * row_dis + (-1) ** (j + 1) * alternate
        start_angle = 2 / 3 * pi * (-1) ** j
        stop_angle = 1 / 3 * pi * (-1) ** j
        arc_x, arc_y = arc(center_x, center_y, radius, start_angle,
                           stop_angle, max_dis)
        pts_x_single = np.hstack((pts_x_single, arc_x))
        pts_y_single = np.hstack((pts_y_single, arc_y))
    x1, y1 = pts_x_single[-1] + side_offset, pts_y_single[-1]
    x2, y2 = x1, y1 + row_dis
    pts_x_single = np.hstack((pts_x_single, [x1, x2]))
    pts_y_single = np.hstack((pts_y_single, [y1, y2]))
    for j in range(circle_number):
        center_x = side_offset + circle_number * radius - (0.5 + j) * radius
        center_y = (2 * i + 1) * row_dis + (-1) ** (j + 1) * alternate
        stop_angle = 2 / 3 * pi * (-1) ** j
        start_angle = 1 / 3 * pi * (-1) ** j
        arc_x, arc_y = arc(center_x, center_y, radius, start_angle,
                           stop_angle, max_dis)
        pts_x_single = np.hstack((pts_x_single, arc_x))
        pts_y_single = np.hstack((pts_y_single, arc_y))
    x1, y1 = pts_x_single[-1] - side_offset, pts_y_single[-1]
    x2, y2 = x1, y1 + row_dis
    pts_x_single = np.hstack((pts_x_single, [x1, x2]))
    pts_y_single = np.hstack((pts_y_single, [y1, y2]))
pts_single = np.column_stack((pts_x_single, pts_y_single))

cx = side_offset + (circle_number / 2 - 0.5) * radius
cy = -0.5*alternate + ((1 + circle_number / 2) / 2 - 0.5) * 2 * row_dis
center = (cx, cy)
pts_single_rotated_1 = rotate_points(pts_single, pi/3, center)
pts_single_rotated_2 = rotate_points(pts_single, -pi/3, center)
pts_x_single = np.hstack(( np.array([0]), pts_single_rotated_1[:,0], pts_single_rotated_2[:,0], np.array([0])))
pts_y_single = np.hstack(( np.array([0]),pts_single_rotated_1[:,1], pts_single_rotated_2[:,1], np.array([pts_single_rotated_2[-1, 1]])))
cycle_number = 2  # variable
pts_x = pts_x_single
pts_y = pts_y_single
for i in range(cycle_number - 1):
    pts_x = np.append(pts_x,  pts_x_single)
    pts_y = np.append(pts_y, pts_y_single)
pts = np.column_stack((pts_x, pts_y))
pts = Path_fill(points=pts, max_dis=0.5)
pts = remove_adjacent_duplicates(pts)
plt.plot(pts[:, 0], pts[:, 1])
plt.axis('equal')
plt.show()
